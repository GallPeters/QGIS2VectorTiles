"""Convert QGIS Vector Tile Layer styles to MapLibre GL JSON style format."""

import json
import math
import os
from os.path import join
from typing import Any, Dict, List, Optional, Union

from qgis.PyQt.QtGui import QColor
from ..utils.config import Qt
from qgis.core import (
    Qgis,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsCsException,
    QgsUnitTypes,
    QgsVectorTileLayer,
    QgsVectorTileBasicRenderer,
    QgsVectorTileBasicLabeling,
    QgsSymbol,
    QgsPalLayerSettings,
    QgsSimpleLineSymbolLayer,
    QgsSimpleFillSymbolLayer,
    QgsProcessingUtils,
    QgsExpression,
    QgsProperty,
    QgsSymbolLayer,
    QgsTextFormat,
    QgsProject,
    QgsTextBackgroundSettings,
)
from qgis.utils import iface
from .glyphs_generator import GlyphGenerator
from .sprite_generator import FillPattern, SpriteGenerator
from .rules_exporter import _TEMP_RULE_FORMAT
from ..utils.config import _SPRITE_QUALITY, _TILES_MAX_ZOOM


class PropertyExtractor:
    """Utility class for extracting and converting PyQGIS properties to MapLibre format.

    Provides shared helpers used by every specialised extractor:
    - Resolution of static vs. data-defined values into MapLibre expressions.
    - Conversion of ``QColor`` instances into MapLibre ``rgba()`` strings.
    - Conversion of QGIS length units into pixels at a 96 DPI baseline.
    """

    # Conversion factors to pixels at 96 DPI, keyed by unit string keywords.
    _UNIT_KEYWORDS: dict = {
        "millimeter": 3.78, "mm": 3.78,
        "inch": 96.0, "in": 96.0,
        "point": 96.0 / 72.0, "pt": 96.0 / 72.0,
        "pixel": 1.0, "px": 1.0,
    }
    # QgsUnitTypes enum integer values → conversion factors.
    _UNIT_ENUMS: dict = {0: 3.78, 2: 1.0, 4: 96.0 / 72.0, 5: 96.0}
    # Map-based units: a length on the ground, so its pixel size depends on the zoom.
    _MAP_UNITS = 1
    _METERS_IN_MAP_UNITS = 7
    # EPSG:3857 metres per web map pixel at zoom 0 (MapLibre's 512 px tiles).
    _MERCATOR_M_PER_PX_Z0 = 40075016.68557849 / 512
    # EPSG:3857 metres per map unit / per ground metre at the data, set per export.
    map_unit_m = 1.0
    ground_m = 1.0

    @staticmethod
    def get_value_or_expression(value: Any, prop: QgsProperty) -> Union[Any, List]:
        """Return a static value or a MapLibre ``["get", field]`` expression.

        If the supplied ``QgsProperty`` is active and references a tile attribute
        (``q2vt*`` field naming convention), a MapLibre expression is returned so
        the property is data-driven at render time. Otherwise the original
        ``value`` is returned unchanged.

        Args:
            value: The static fallback value to use when no data-defined override applies.
            prop:  The data-defined property descriptor from QGIS.

        Returns:
            Either the original ``value`` or a MapLibre expression list.
        """
        if prop and prop.isActive():
            expression = prop.expressionString()
            qexpr = QgsExpression(expression)
            evaluation = qexpr.evaluate()
            if evaluation:
                return evaluation
            field_name = expression.replace('"', "")
            idx = field_name.find("q2vt")
            if field_name and idx != -1:
                extracted_name = [part for part in field_name.split(' ') if part.startswith('q2vt')][0]
                return ["get", extracted_name.replace(',', '')]
        return value

    @staticmethod
    def convert_qcolor_to_maplibre(color: QColor) -> str:
        """Convert a ``QColor`` into a MapLibre-compatible ``rgba()`` string.

        Args:
            color: The Qt color to convert.

        Returns:
            A string in the form ``"rgba(r, g, b, a)"`` where alpha is normalised
            to the ``[0, 1]`` range expected by MapLibre.
        """
        return f"rgba({color.red()}, {color.green()}, {color.blue()}, {color.alphaF()})"

    @classmethod
    def convert_length_to_pixels(cls, value: float, unit_obj=None) -> float:
        """Convert a length value from a QGIS unit into pixels at 96 DPI.

        The unit can be supplied as either a textual hint (e.g. ``"MM"``,
        ``"Pixels"``) or as a ``QgsUnitTypes`` enum integer. When the unit is
        unknown, the value is treated as millimetres.

        Args:
            value:    The length to convert.
            unit_obj: A unit descriptor; either a string-like or enum integer.

        Returns:
            The equivalent pixel value (float).
        """
        if value is None:
            return value

        try:
            unit_str = str(unit_obj).lower() if unit_obj is not None else ""
        except (OSError, RuntimeError):
            unit_str = ""

        for keyword, factor in cls._UNIT_KEYWORDS.items():
            if keyword in unit_str:
                return value * factor

        try:
            factor = cls._UNIT_ENUMS.get(unit_obj)
            if factor is not None:
                return value * factor
        except (RuntimeError, AttributeError):
            pass

        return value * 3.78  # Default: treat as millimetres

    @staticmethod
    def enum_int(enum_obj) -> Optional[int]:
        """A QGIS/Qt enum value as an integer (Qt5 gives ints, Qt6 enums)."""
        try:
            return int(getattr(enum_obj, "value", enum_obj))
        except (TypeError, ValueError):
            return None

    @classmethod
    def is_map_unit(cls, unit_obj) -> bool:
        """Whether a length is on the ground (map units or metres) rather than on screen."""
        return cls.enum_int(unit_obj) in (cls._MAP_UNITS, cls._METERS_IN_MAP_UNITS)

    @classmethod
    def length_to_style_value(cls, value: float, unit_obj=None) -> Union[float, List]:
        """A length as a MapLibre value: pixels, or a zoom expression for ground lengths.

        A ground length doubles in pixels with every zoom level, which an
        exponential base-2 interpolation reproduces exactly.
        """
        if value is None or not cls.is_map_unit(unit_obj):
            return cls.convert_length_to_pixels(value, unit_obj)
        metres = cls.map_unit_m if cls.enum_int(unit_obj) == cls._MAP_UNITS else cls.ground_m
        px_z0 = value * metres / cls._MERCATOR_M_PER_PX_Z0
        return ["interpolate", ["exponential", 2], ["zoom"], 0, px_z0, 24, px_z0 * 2 ** 24]

    @classmethod
    def set_map_units(cls, crs, latitude: float) -> None:
        """Set how many EPSG:3857 metres a map unit and a ground metre are at the data.

        Web Mercator stretches ground lengths by 1/cos(latitude); a project
        in Web Mercator already draws its map units stretched that way.
        """
        stretch = 1.0 / max(math.cos(math.radians(latitude)), 0.01)
        cls.ground_m = stretch
        cls.map_unit_m = stretch
        try:
            if crs.isGeographic():
                cls.map_unit_m = 111319.49079327357  # 3857 metres per degree of longitude
            elif crs.authid() in ("EPSG:3857", "EPSG:900913", "EPSG:3785"):
                cls.map_unit_m = 1.0
            else:
                cls.map_unit_m = stretch * QgsUnitTypes.fromUnitToUnitFactor(
                    crs.mapUnits(), Qgis.DistanceUnit.Meters
                )
        except (AttributeError, RuntimeError, TypeError):
            pass

    @staticmethod
    def get_attribute(obj: Any, *names) -> Any:
        """Fetch the first available attribute from ``obj`` matching any of ``names``.

        Tries each attribute name in turn, returning the resolved value
        (calling it if callable). Returns ``None`` if no attribute exists or
        every access fails.

        Args:
            obj:    The object to inspect.
            *names: Attribute names to try, in order.

        Returns:
            The resolved value, or ``None`` if every name fails.
        """
        for name in names:
            if hasattr(obj, name):
                try:
                    attr = getattr(obj, name)
                    return attr() if callable(attr) else attr
                except (RuntimeError, AttributeError, OSError):
                    continue
        return None


class LinePropertyExtractor:
    """Extract line paint and layout properties from QGIS line symbol layers."""

    @staticmethod
    def get_line_color(symbol_layer: QgsSimpleLineSymbolLayer) -> Union[str, List]:
        """Return ``line-color`` resolving any data-defined override."""
        base_color = PropertyExtractor.convert_qcolor_to_maplibre(symbol_layer.color())
        color_prop = symbol_layer.dataDefinedProperties().property(QgsSymbolLayer.Property.PropertyStrokeColor)
        return PropertyExtractor.get_value_or_expression(base_color, color_prop)

    @staticmethod
    def get_line_width(symbol_layer: QgsSimpleLineSymbolLayer) -> Union[float, List]:
        """Return ``line-width`` in pixels, resolving any data-defined override."""
        width_unit = PropertyExtractor.get_attribute(
            symbol_layer, "widthUnit", "widthUnits", "strokeWidthUnit", "strokeWidthUnits"
        )
        width_px = PropertyExtractor.length_to_style_value(symbol_layer.width(), width_unit)
        width_prop = symbol_layer.dataDefinedProperties().property(
            QgsSymbolLayer.Property.PropertyStrokeWidth
        )
        return PropertyExtractor.get_value_or_expression(width_px, width_prop)

    @staticmethod
    def get_line_opacity(
        symbol_layer: QgsSimpleLineSymbolLayer, symbol: "QgsSymbol" = None
    ) -> Union[float, List]:
        """Return ``line-opacity`` from the symbol's general Opacity setting.

        Independent of the stroke colour's alpha channel: that alpha is already
        embedded in the ``line-color`` rgba() string, and MapLibre multiplies
        ``line-opacity`` against it at render time. ``symbol.opacity()`` is
        QGIS's own general "Opacity" slider (top of the Symbol panel) - a
        separate multiplier from colour alpha. Honours a data-defined
        ``Property.PropertyOpacity`` override when active.
        """
        try:
            base_opacity = symbol.opacity() if symbol is not None else 1.0
        except (AttributeError, RuntimeError):
            base_opacity = 1.0
        try:
            opacity_prop = symbol_layer.dataDefinedProperties().property(
                QgsSymbolLayer.Property.Property.PropertyOpacity
            )
            return PropertyExtractor.get_value_or_expression(base_opacity, opacity_prop)
        except (AttributeError, RuntimeError):
            return base_opacity

    @staticmethod
    def get_line_cap(symbol_layer: QgsSimpleLineSymbolLayer) -> str:
        """Return ``line-cap`` mapped from the Qt pen-cap style."""
        cap_map = {0: "butt", 16: "square", 32: "round"}
        return cap_map.get(PropertyExtractor.enum_int(symbol_layer.penCapStyle()), "round")

    @staticmethod
    def get_line_join(symbol_layer: QgsSimpleLineSymbolLayer) -> str:
        """Return ``line-join`` mapped from the Qt pen-join style."""
        # Qt's SvgMiterJoin (256) is a miter join too.
        join_map = {0: "miter", 64: "bevel", 128: "round", 256: "miter"}
        return join_map.get(PropertyExtractor.enum_int(symbol_layer.penJoinStyle()), "round")

    @staticmethod
    def get_line_miter_limit() -> float:
        """Return ``line-miter-limit`` (MapLibre default: 2.0)."""
        return 2.0

    @staticmethod
    def get_line_round_limit() -> float:
        """Return ``line-round-limit`` (MapLibre default: 1.05)."""
        return 1.05

    @staticmethod
    def get_line_dasharray(
        symbol_layer: QgsSimpleLineSymbolLayer, width_px: float
    ) -> Optional[List[float]]:
        """Return ``line-dasharray`` from a custom dash vector or pen-style preset.

        Custom dash patterns take precedence over Qt's pen-style enum presets.
        MapLibre dash lengths are multiples of the line width, so custom
        lengths are converted to pixels and divided by ``width_px``. When no
        dashing is configured, ``None`` is returned and ``line-dasharray``
        should be omitted.
        """
        dash_vector = None
        try:
            dash_vector = symbol_layer.customDashVector()
        except (RuntimeError, AttributeError):
            pass

        custom_dash_enabled = False
        try:
            for attr in ("useCustomDashPattern", "customDashEnabled", "isCustomDash"):
                if hasattr(symbol_layer, attr):
                    custom_dash_enabled = bool(getattr(symbol_layer, attr)())
                    break
        except (RuntimeError, AttributeError):
            pass

        pen_style = PropertyExtractor.get_attribute(
            symbol_layer, "penStyle", "strokeStyle", "pen_style"
        )

        if custom_dash_enabled and dash_vector:
            dash_unit = PropertyExtractor.get_attribute(
                symbol_layer, "customDashPatternUnit", "customDashVectorUnit"
            )
            width_unit = PropertyExtractor.get_attribute(
                symbol_layer, "widthUnit", "widthUnits", "strokeWidthUnit", "strokeWidthUnits"
            )
            unit = PropertyExtractor.enum_int(dash_unit or width_unit)
            if PropertyExtractor.is_map_unit(width_unit) and unit == PropertyExtractor.enum_int(width_unit):
                # Ground dashes on a ground width: the ratio holds at every zoom.
                width = symbol_layer.width() or 1.0
                return [d / width for d in dash_vector]
            width = width_px if width_px and width_px > 0 else 1.0
            return [
                PropertyExtractor.convert_length_to_pixels(d, dash_unit or width_unit) / width
                for d in dash_vector
            ]

        # Qt's own patterns, as [dash, gap, ...] multiples of the line width.
        fixed_presets = {
            2: [4, 2],             # DashLine
            3: [1, 2],             # DotLine
            4: [4, 2, 1, 2],       # DashDotLine
            5: [4, 2, 1, 2, 1, 2], # DashDotDotLine
        }
        return fixed_presets.get(PropertyExtractor.enum_int(pen_style))

    @staticmethod
    def get_line_offset(symbol_layer: QgsSimpleLineSymbolLayer) -> Union[float, List]:
        """Return ``line-offset`` in pixels (positive values offset to the right).

        Honours a data-defined ``PropertyOffset`` override when active. Note
        that data-defined offsets are emitted in QGIS units (pixels for the
        static path); for field-based overrides the user must supply pixel
        values to match the MapLibre rendering convention.
        """
        base_offset = 0.0
        try:
            offset = symbol_layer.offset()
            if offset != 0:
                offset_unit = PropertyExtractor.get_attribute(
                    symbol_layer, "offsetUnit", "offsetUnits"
                )
                base_offset = PropertyExtractor.length_to_style_value(offset, offset_unit)
        except (RuntimeError, AttributeError):
            pass

        try:
            offset_prop = symbol_layer.dataDefinedProperties().property(
                QgsSymbolLayer.Property.PropertyOffset
            )
            return PropertyExtractor.get_value_or_expression(base_offset, offset_prop)
        except (AttributeError, RuntimeError):
            return base_offset

    @staticmethod
    def get_line_blur() -> float:
        """Return ``line-blur`` in pixels (MapLibre default: 0)."""
        return 0

    @staticmethod
    def get_line_gap_width() -> float:
        """Return ``line-gap-width`` in pixels (MapLibre default: 0)."""
        return 0

    @staticmethod
    def get_line_translate() -> List[float]:
        """Return ``line-translate`` ``[x, y]`` offset in pixels (default ``[0, 0]``)."""
        return [0, 0]

    @staticmethod
    def get_line_translate_anchor() -> str:
        """Return ``line-translate-anchor`` (MapLibre default: ``"map"``)."""
        return "map"

    @staticmethod
    def get_line_sort_key(symbol_layer: QgsSymbolLayer) -> Union[float, List]:
        """Return ``line-sort-key`` honouring any data-defined override.

        The static default is ``0``; if a data-defined ``RenderingOrder`` (or
        equivalent) property is active on the layer, the corresponding
        MapLibre expression is emitted instead.
        """
        order_prop = None
        try:
            order_prop = symbol_layer.dataDefinedProperties().property(
                QgsSymbolLayer.Property.PropertyLayerEnabled
            )
        except (AttributeError, RuntimeError):
            pass
        return PropertyExtractor.get_value_or_expression(0, order_prop)

    @staticmethod
    def is_pattern_line(symbol_layer: QgsSymbolLayer) -> bool:
        """Return ``True`` if this line symbol layer represents a raster pattern.

        Pattern detection is performed by class-name inspection so QGIS
        versions lacking a particular subclass remain compatible.
        """
        pattern_class_names = {
            "QgsRasterLineSymbolLayer",
            "QgsLineburstSymbolLayer",
        }
        return type(symbol_layer).__name__ in pattern_class_names

    @staticmethod
    def get_line_pattern_path(symbol_layer: QgsSymbolLayer) -> Optional[str]:
        """Return the source image path for a pattern line, or ``None``.

        Used by the converter to register a pattern image with the sprite
        pipeline and to populate ``line-pattern``.
        """
        path = PropertyExtractor.get_attribute(symbol_layer, "path", "imagePath")
        if isinstance(path, str) and path:
            return path
        return None

    @staticmethod
    def is_marker_line(symbol_layer: QgsSymbolLayer) -> bool:
        """Return ``True`` if this line symbol layer decorates the line with markers.

        Detected by class-name inspection (matching the ``is_pattern_line``
        convention above) so QGIS versions lacking the symbol-layer class
        remain compatible.
        """
        return type(symbol_layer).__name__ == "QgsMarkerLineSymbolLayer"

    @staticmethod
    def get_marker_line_symbol_placement(symbol_layer: QgsSymbolLayer) -> str:
        """Map QGIS marker-line placement to MapLibre ``symbol-placement``.

        QGIS ``QgsMarkerLineSymbolLayer.Placement`` values: ``Interval=0``,
        ``Vertex=1``, ``LastVertex=2``, ``FirstVertex=3``,
        ``CentralPoint=4``, ``CurvePoint=5``, ``SegmentCenter=6``. MapLibre
        only supports evenly-spaced (``"line"``) or once-per-line
        (``"line-center"``) symbol placement, so the richer QGIS enum is
        folded into the closest MapLibre equivalent.
        """
        placement = None
        try:
            placement = PropertyExtractor.enum_int(symbol_layer.placement())
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass
        # CentralPoint / SegmentCenter -> a single marker centred on the line.
        if placement in (4, 6):
            return "line-center"
        # Interval / Vertex / First / Last / Curve point -> repeat along line.
        return "line"

    @staticmethod
    def get_marker_line_spacing(symbol_layer: QgsSymbolLayer) -> float:
        """Return ``symbol-spacing`` in pixels from the marker-line interval.

        Uses the QGIS ``interval()`` (converted to pixels via
        ``intervalUnit()``) whenever it is set. Vertex-based placements
        without an explicit interval fall back to a tight spacing so that
        MapLibre's evenly-spaced rendering approximates "one marker per
        vertex"; all other cases fall back to the MapLibre default (250px).
        """
        try:
            placement = PropertyExtractor.enum_int(symbol_layer.placement())
        except (AttributeError, RuntimeError, TypeError, ValueError):
            placement = 0

        try:
            interval = float(symbol_layer.interval())
        except (AttributeError, RuntimeError, TypeError, ValueError):
            interval = 0.0

        if interval > 0:
            unit = PropertyExtractor.get_attribute(
                symbol_layer, "intervalUnit", "intervalUnits"
            )
            return PropertyExtractor.convert_length_to_pixels(interval, unit)

        # Vertex / FirstVertex / LastVertex / CurvePoint without an explicit
        # interval: MapLibre has no vertex-placement equivalent, so a small
        # fixed spacing approximates dense per-vertex markers.
        if placement in (1, 2, 3, 5):
            return 1.0

        return 250.0

    @staticmethod
    def get_marker_line_rotate_symbols(symbol_layer: QgsSymbolLayer) -> bool:
        """Return whether markers should rotate to follow the line bearing.

        Mirrors QGIS ``rotateSymbols()``; defaults to ``True`` (QGIS's own
        default) if the property cannot be read.
        """
        try:
            return bool(symbol_layer.rotateSymbols())
        except (AttributeError, RuntimeError):
            return True

    @staticmethod
    def get_marker_line_offset(symbol_layer: QgsSymbolLayer) -> float:
        """Return the marker-line's perpendicular offset from the line, in pixels.

        Positive QGIS offsets shift markers to the left of the line
        direction; ``0`` is returned (and the caller should omit
        ``icon-offset``) when no offset is configured.
        """
        try:
            offset = float(symbol_layer.offset())
        except (AttributeError, RuntimeError, TypeError, ValueError):
            return 0.0
        if offset == 0:
            return 0.0
        unit = PropertyExtractor.get_attribute(symbol_layer, "offsetUnit", "offsetUnits")
        return PropertyExtractor.convert_length_to_pixels(offset, unit)


class FillPropertyExtractor:
    """Extract fill paint and layout properties from QGIS fill symbol layers."""

    @staticmethod
    def get_fill_color(symbol_layer: QgsSimpleFillSymbolLayer) -> Union[str, List]:
        """Return ``fill-color`` resolving any data-defined override."""
        base_color = PropertyExtractor.convert_qcolor_to_maplibre(symbol_layer.color())
        color_prop = symbol_layer.dataDefinedProperties().property(QgsSymbolLayer.Property.PropertyFillColor)
        return PropertyExtractor.get_value_or_expression(base_color, color_prop)

    @staticmethod
    def get_fill_opacity(
        symbol_layer: QgsSimpleFillSymbolLayer, symbol: "QgsSymbol" = None
    ) -> Union[float, List]:
        """Return ``fill-opacity`` from the symbol's general Opacity setting.

        Independent of the fill colour's alpha channel, for the same reason as
        ``get_line_opacity``: colour alpha lives in ``fill-color``, and
        ``symbol.opacity()`` is QGIS's separate general "Opacity" slider.
        Honours a data-defined ``Property.PropertyOpacity`` override when active.
        """
        try:
            base_opacity = symbol.opacity() if symbol is not None else 1.0
        except (AttributeError, RuntimeError):
            base_opacity = 1.0
        try:
            opacity_prop = symbol_layer.dataDefinedProperties().property(
                QgsSymbolLayer.Property.PropertyOpacity
            )
            return PropertyExtractor.get_value_or_expression(base_opacity, opacity_prop)
        except (AttributeError, RuntimeError):
            return base_opacity

    @staticmethod
    def get_fill_outline_color(
        symbol_layer: QgsSimpleFillSymbolLayer,
    ) -> Union[str, List, None]:
        """Return ``fill-outline-color`` if the polygon stroke is visible."""
        try:
            stroke_visible = symbol_layer.strokeWidth() > 0 and symbol_layer.strokeStyle() != 0
        except (AttributeError, RuntimeError):
            stroke_visible = False
        if stroke_visible:
            base_color = PropertyExtractor.convert_qcolor_to_maplibre(symbol_layer.strokeColor())
            color_prop = symbol_layer.dataDefinedProperties().property(
                QgsSymbolLayer.Property.PropertyStrokeColor
            )
            return PropertyExtractor.get_value_or_expression(base_color, color_prop)
        return None

    @staticmethod
    def get_fill_antialias() -> bool:
        """Return ``fill-antialias`` (MapLibre default: ``True``)."""
        return True

    @staticmethod
    def get_fill_translate() -> List[float]:
        """Return ``fill-translate`` ``[x, y]`` offset in pixels (default ``[0, 0]``)."""
        return [0, 0]

    @staticmethod
    def get_fill_translate_anchor() -> str:
        """Return ``fill-translate-anchor`` (MapLibre default: ``"map"``)."""
        return "map"

    @staticmethod
    def get_fill_sort_key(symbol_layer: QgsSymbolLayer) -> Union[float, List]:
        """Return ``fill-sort-key`` honouring any data-defined override."""
        order_prop = None
        try:
            order_prop = symbol_layer.dataDefinedProperties().property(
                QgsSymbolLayer.Property.PropertyLayerEnabled
            )
        except (AttributeError, RuntimeError):
            pass
        return PropertyExtractor.get_value_or_expression(0, order_prop)

    @staticmethod
    def is_pattern_fill(symbol_layer: QgsSymbolLayer) -> bool:
        """Return ``True`` for pattern-based fill layers (point/line/raster/SVG)."""
        pattern_class_names = {
            "QgsPointPatternFillSymbolLayer",
            "QgsLinePatternFillSymbolLayer",
            "QgsRasterFillSymbolLayer",
            "QgsSVGFillSymbolLayer",
            "QgsRandomMarkerFillSymbolLayer",
        }
        return type(symbol_layer).__name__ in pattern_class_names

    # Tile size of a non-repeating pattern (random markers), in pixels.
    _RANDOM_PATTERN_TILE = 128.0

    @staticmethod
    def get_pattern_tile_size(symbol_layer: QgsSymbolLayer) -> tuple:
        """The pattern's repeat (width, height) in pixels: one tile of ``fill-pattern``.

        A tile of exactly one repeat makes MapLibre's repeated image seamless.
        Point grids repeat every distance (twice that along a row
        displacement); parallel lines every distance / sin or cos of their
        angle; SVG and raster images every image width and its height.
        """
        px = PropertyExtractor.convert_length_to_pixels
        get = PropertyExtractor.get_attribute
        kind = type(symbol_layer).__name__
        try:
            if kind == "QgsPointPatternFillSymbolLayer":
                width = px(symbol_layer.distanceX(), get(symbol_layer, "distanceXUnit"))
                height = px(symbol_layer.distanceY(), get(symbol_layer, "distanceYUnit"))
                if symbol_layer.displacementX():
                    height *= 2
                if symbol_layer.displacementY():
                    width *= 2
                return width, height
            if kind == "QgsLinePatternFillSymbolLayer":
                distance = px(symbol_layer.distance(), get(symbol_layer, "distanceUnit"))
                angle = math.radians(symbol_layer.lineAngle())
                sin, cos = abs(math.sin(angle)), abs(math.cos(angle))
                # A tile edge parallel to the lines can be any length: use the distance.
                width = distance / sin if sin > 1e-3 else distance
                height = distance / cos if cos > 1e-3 else distance
                return width, height
            if kind == "QgsSVGFillSymbolLayer":
                from qgis.PyQt.QtSvg import QSvgRenderer
                width = px(symbol_layer.patternWidth(), get(symbol_layer, "patternWidthUnit"))
                box = QSvgRenderer(symbol_layer.svgFilePath()).viewBoxF()
                ratio = box.height() / box.width() if box.width() > 0 else 1.0
                return width, width * ratio
            if kind == "QgsRasterFillSymbolLayer":
                from qgis.PyQt.QtGui import QImageReader
                size = QImageReader(symbol_layer.imageFilePath()).size()
                width = symbol_layer.width()
                width = px(width, get(symbol_layer, "sizeUnit", "widthUnit")) if width > 0 else size.width()
                ratio = size.height() / size.width() if size.width() > 0 else 1.0
                return width, width * ratio
        except (AttributeError, RuntimeError, TypeError, ValueError, ImportError):
            pass
        return FillPropertyExtractor._RANDOM_PATTERN_TILE, FillPropertyExtractor._RANDOM_PATTERN_TILE

    @staticmethod
    def get_fill_pattern_path(symbol_layer: QgsSymbolLayer) -> Optional[str]:
        """Return the source image path for a raster/SVG fill pattern, or ``None``."""
        path = PropertyExtractor.get_attribute(symbol_layer, "imageFilePath", "svgFilePath", "path")
        if isinstance(path, str) and path:
            return path
        return None


class IconPropertyExtractor:
    """Extract icon paint and layout properties for MapLibre symbol layers."""

    @staticmethod
    def get_icon_image(marker_name: str) -> str:
        """Return the registered sprite name for ``icon-image``."""
        return marker_name

    @staticmethod
    def get_icon_size(
        symbol_layer: QgsSymbolLayer, default_size: float = 1.0
    ) -> Union[float, List]:
        """Return ``icon-size`` honouring any data-defined override.

        The sprite draws the marker at its own size (times _SPRITE_QUALITY).
        A data-defined size is a marker size, not a scale, so the icon is
        scaled by its ratio to the marker's own size: a constant becomes a
        number, a field a MapLibre expression.
        """
        size_prop = symbol_layer.dataDefinedProperties().property(QgsSymbolLayer.Property.PropertySize)
        size_val = PropertyExtractor.get_value_or_expression(default_size, size_prop)
        if size_val is default_size:
            return default_size / _SPRITE_QUALITY
        try:
            base = float(symbol_layer.size())
        except (AttributeError, TypeError, ValueError):
            base = 0.0
        if base <= 0:
            return default_size / _SPRITE_QUALITY
        if isinstance(size_val, list):
            return ["/", ["to-number", size_val, base], base * _SPRITE_QUALITY]
        try:
            return float(size_val) / base / _SPRITE_QUALITY
        except (TypeError, ValueError):
            return default_size / _SPRITE_QUALITY

    @staticmethod
    def get_icon_rotate(
        symbol_layer: QgsSymbolLayer = None,
        background: QgsTextBackgroundSettings = None,
    ) -> Union[float, List]:
        """Return ``icon-rotate`` in degrees, honouring data-defined overrides.

        When given a marker symbol layer, the static rotation is taken from
        ``angle()`` and any active ``PropertyAngle`` data-defined override is
        applied. When given a label background, the background rotation is
        used instead.
        """
        if symbol_layer is not None:
            base_angle = 0.0
            try:
                base_angle = float(symbol_layer.angle())
            except (AttributeError, RuntimeError, TypeError):
                pass
            try:
                angle_prop = symbol_layer.dataDefinedProperties().property(
                    QgsSymbolLayer.Property.PropertyAngle
                )
                return PropertyExtractor.get_value_or_expression(base_angle, angle_prop)
            except (AttributeError, RuntimeError):
                return base_angle
        if background is not None and background.enabled():
            try:
                return float(background.rotation())
            except (AttributeError, RuntimeError, TypeError):
                return 0.0
        return 0.0

    @staticmethod
    def get_icon_padding() -> float:
        """Return ``icon-padding`` in pixels (MapLibre default: 2)."""
        return 1

    @staticmethod
    def get_icon_rotation_alignment() -> str:
        """Return ``icon-rotation-alignment`` (default: ``"map"`` for QGIS markers)."""
        return "map"

    @staticmethod
    def get_icon_pitch_alignment() -> str:
        """Return ``icon-pitch-alignment`` (default: ``"viewport"``)."""
        return "viewport"

    @staticmethod
    def get_icon_anchor() -> str:
        """Return ``icon-anchor`` (default: ``"center"``)."""
        return "center"

    @staticmethod
    def get_icon_allow_overlap(allow_overlap: bool = False) -> bool:
        """Return ``icon-allow-overlap`` (MapLibre default: ``False``)."""
        return allow_overlap

    @staticmethod
    def get_icon_ignore_placement() -> bool:
        """Return ``icon-ignore-placement`` (MapLibre default: ``False``)."""
        return False

    @staticmethod
    def get_icon_optional() -> bool:
        """Return ``icon-optional`` (MapLibre default: ``False``)."""
        return False

    @staticmethod
    def get_icon_keep_upright() -> bool:
        """Return ``icon-keep-upright``.

        Defaults to ``True`` to match QGIS rendering for line-aligned markers.
        """
        return True

    @staticmethod
    def get_icon_text_fit(background: QgsTextBackgroundSettings) -> Optional[str]:
        """Return ``icon-text-fit`` if the background is sized as a text buffer."""
        if background.enabled() and background.sizeType() == 0:
            return "both"
        return None

    @staticmethod
    def get_icon_text_fit_padding(
        background: QgsTextBackgroundSettings,
    ) -> Optional[List[float]]:
        """Return ``icon-text-fit-padding`` ``[top, right, bottom, left]`` from buffer size."""
        if background.enabled() and background.sizeType() == 0:
            buf_px = PropertyExtractor.convert_length_to_pixels(
                background.size().width(), background.sizeUnit()
            )
            buf_px = max(buf_px, 3)  
            return [buf_px * 2, buf_px, buf_px * 2, buf_px]
        return None

    @staticmethod
    def get_icon_offset(background: QgsTextBackgroundSettings = None) -> List[float]:
        """Return ``icon-offset`` ``[x, y]`` in pixels from background offset settings."""
        if background and background.enabled():
            offset = background.offset()
            unit = background.offsetUnit()
            return [
                PropertyExtractor.convert_length_to_pixels(offset.x(), unit),
                PropertyExtractor.convert_length_to_pixels(offset.y(), unit),
            ]
        return [0, 0]

    @staticmethod
    def get_icon_opacity(background: QgsTextBackgroundSettings = None) -> float:
        """Return ``icon-opacity`` from background settings (default ``1.0``)."""
        if background and background.enabled():
            try:
                return background.opacity()
            except (OSError, RuntimeError):
                pass
        return 1.0

    @staticmethod
    def get_icon_color(background: QgsTextBackgroundSettings = None) -> str:
        """Return ``icon-color`` from background fill colour (default white)."""
        if background and background.enabled():
            try:
                return PropertyExtractor.convert_qcolor_to_maplibre(background.fillColor())
            except (OSError, RuntimeError):
                pass
        return "rgb(255, 255, 255)"

    @staticmethod
    def get_icon_halo_color(background: QgsTextBackgroundSettings = None) -> str:
        """Return ``icon-halo-color``.

        When a label background is provided and has a stroke, the stroke
        colour is used; otherwise black is returned to match the MapLibre
        default.
        """
        if background and background.enabled():
            try:
                return PropertyExtractor.convert_qcolor_to_maplibre(background.strokeColor())
            except (OSError, RuntimeError, AttributeError):
                pass
        return "rgb(0, 0, 0)"

    @staticmethod
    def get_icon_halo_width(background: QgsTextBackgroundSettings = None) -> float:
        """Return ``icon-halo-width`` in pixels from the background stroke width."""
        if background and background.enabled():
            try:
                return PropertyExtractor.convert_length_to_pixels(
                    background.strokeWidth(), background.strokeWidthUnit()
                )
            except (OSError, RuntimeError, AttributeError):
                pass
        return 0

    @staticmethod
    def get_icon_halo_blur() -> float:
        """Return ``icon-halo-blur`` in pixels (default 0)."""
        return 0

    @staticmethod
    def get_icon_translate() -> List[float]:
        """Return ``icon-translate`` ``[x, y]`` offset in pixels (default ``[0, 0]``)."""
        return [0, 0]

    @staticmethod
    def get_icon_translate_anchor() -> str:
        """Return ``icon-translate-anchor`` (MapLibre default: ``"map"``)."""
        return "map"

    @staticmethod
    def get_symbol_placement(label_settings: QgsPalLayerSettings = None) -> str:
        """Return ``symbol-placement`` (``"point"``, ``"line"``, or ``"line-center"``).

        Mapped from ``QgsPalLayerSettings.placement``: line/curved/perimeter
        placements become ``"line"``; everything else becomes ``"point"``.
        """
        if label_settings is None:
            return "point"
        try:
            placement = PropertyExtractor.enum_int(label_settings.placement)
        except AttributeError:
            return "point"
        # QgsPalLayerSettings placement enum: 2=Line, 3=Curved, 7=PerimeterCurved, 8=OutsidePolygons
        line_placements = (2, 3, 7, 8)
        if placement in line_placements:
            return "line"
        return "point"

    @staticmethod
    def get_symbol_spacing(label_settings: QgsPalLayerSettings = None) -> float:
        """Return ``symbol-spacing`` in pixels (MapLibre default: 250).

        Sourced from ``label_settings.repeatDistance`` when set; otherwise
        the MapLibre default of 250 px is returned.
        """
        if label_settings is None:
            return 250.0
        try:
            distance = label_settings.repeatDistance
            if distance and distance > 0:
                unit = PropertyExtractor.get_attribute(
                    label_settings, "repeatDistanceUnit", "distUnits"
                )
                return PropertyExtractor.convert_length_to_pixels(distance, unit)
        except (AttributeError, RuntimeError):
            pass
        return 250.0

    @staticmethod
    def get_symbol_avoid_edges() -> bool:
        """Return ``symbol-avoid-edges`` (MapLibre default: ``False``)."""
        return False

    @staticmethod
    def get_symbol_sort_key() -> float:
        """Return ``symbol-sort-key`` (default 0; lower keys render first)."""
        return 0

    @staticmethod
    def get_symbol_z_order() -> str:
        """Return ``symbol-z-order`` (default ``"auto"``)."""
        return "auto"


class TextPropertyExtractor:
    """Extract text paint and layout properties from QGIS label settings."""

    @staticmethod
    def get_text_field(label_settings: QgsPalLayerSettings) -> Optional[List]:
        """Return ``text-field`` as a MapLibre ``["get", field]`` expression."""
        if label_settings.fieldName:
            return ["get", label_settings.fieldName]
        return None

    @staticmethod
    def get_text_font(text_format: QgsTextFormat) -> List[str]:
        """Return ``text-font`` as a single-element list of ``"family style"``."""
        font = text_format.font()
        font_str = f"{font.family()} {font.styleName()}"
        return font_str

    @staticmethod
    def get_text_size(
        text_format: QgsTextFormat, label_settings: QgsPalLayerSettings, viewer: int
    ) -> Union[float, List]:
        """Return ``text-size`` in pixels, honouring data-defined overrides."""
        base_size = PropertyExtractor.length_to_style_value(text_format.size(), text_format.sizeUnit())
        size_prop = label_settings.dataDefinedProperties().property(QgsPalLayerSettings.Property.Size)
        return PropertyExtractor.get_value_or_expression(base_size, size_prop)

    @staticmethod
    def get_text_size_px(text_format: QgsTextFormat) -> float:
        """The label's font size in pixels, to turn pixel lengths into ems.

        A size in map units has no single pixel size; 16 px stands in for it.
        """
        if PropertyExtractor.is_map_unit(text_format.sizeUnit()):
            return 16.0
        size = PropertyExtractor.convert_length_to_pixels(text_format.size(), text_format.sizeUnit())
        return size if size and size > 0 else 16.0

    @staticmethod
    def get_text_color(
        text_format: QgsTextFormat, label_settings: QgsPalLayerSettings
    ) -> Union[str, List]:
        """Return ``text-color`` honouring any data-defined override."""
        base_color = PropertyExtractor.convert_qcolor_to_maplibre(text_format.color())
        color_prop = label_settings.dataDefinedProperties().property(QgsPalLayerSettings.Property.Color)
        return PropertyExtractor.get_value_or_expression(base_color, color_prop)

    @staticmethod
    def get_text_opacity(
        text_format: QgsTextFormat,
        label_settings: QgsPalLayerSettings = None,
    ) -> Union[float, List]:
        """Return ``text-opacity`` from the text format's general Opacity setting.

        Independent of the font colour's alpha channel, same reasoning as the
        fill/line variants. ``text_format.opacity()`` is QGIS's own general
        text "Opacity" slider. Honours a data-defined ``FontOpacity`` override
        on ``label_settings`` when active. When the property does not exist on
        the running QGIS build, the static opacity value is returned.
        """
        try:
            base_opacity = text_format.opacity()
        except (AttributeError, RuntimeError):
            base_opacity = 1.0
        if label_settings is None:
            return base_opacity
        try:
            prop_key = getattr(QgsPalLayerSettings, "FontOpacity")
        except AttributeError:
            return base_opacity
        try:
            opacity_prop = label_settings.dataDefinedProperties().property(prop_key)
            return PropertyExtractor.get_value_or_expression(base_opacity, opacity_prop)
        except (AttributeError, RuntimeError):
            return base_opacity

    @staticmethod
    def get_text_halo_color(
        text_format: QgsTextFormat,
        label_settings: QgsPalLayerSettings = None,
    ) -> Union[str, List]:
        """Return ``text-halo-color`` from buffer settings.

        Honours a data-defined ``BufferColor`` override on ``label_settings``
        when active, so per-feature halo colour attributes are emitted as
        MapLibre ``["get", field]`` expressions rather than the hard-coded
        static buffer colour. Falls back to white when the buffer is
        disabled and no override is supplied.
        """
        buffer = text_format.buffer()
        if not buffer.enabled():
            return "rgb(255, 255, 255)"
        base_color = PropertyExtractor.convert_qcolor_to_maplibre(buffer.color())
        if label_settings is None:
            return base_color
        try:
            color_prop = label_settings.dataDefinedProperties().property(
                QgsPalLayerSettings.Property.BufferColor
            )
            return PropertyExtractor.get_value_or_expression(base_color, color_prop)
        except (AttributeError, RuntimeError):
            return base_color

    @staticmethod
    def get_text_halo_width(
        text_format: QgsTextFormat,
        label_settings: QgsPalLayerSettings = None,
        viewer: int = 0
    ) -> Union[float, List]:
        """Return ``text-halo-width`` in pixels from the buffer size.

        Honours a data-defined ``BufferSize`` override on ``label_settings``
        when active. Field-based overrides are returned as MapLibre
        expressions; the user is responsible for storing pixel-equivalent
        values in the source attribute since MapLibre expressions cannot
        express the QGIS unit conversion at evaluation time.
        """
        buffer = text_format.buffer()
        if not buffer.enabled():
            return 0
        # Both are the halo's width outside the letters.
        try:
            base_width = PropertyExtractor.length_to_style_value(
                buffer.size(), buffer.sizeUnit()
            )
        except (AttributeError, RuntimeError):
            base_width = buffer.size()
        if isinstance(base_width, (int, float)):
            # MapLibre draws halos up to about a quarter of the text size;
            # wider ones fill the letter's whole box with a faint colour.
            base_width = min(base_width, 0.2 * TextPropertyExtractor.get_text_size_px(text_format))
        if label_settings is None:
            return base_width
        try:
            size_prop = label_settings.dataDefinedProperties().property(
                QgsPalLayerSettings.Property.BufferSize
            )
            return PropertyExtractor.get_value_or_expression(base_width, size_prop)
        except (AttributeError, RuntimeError):
            return base_width

    @staticmethod
    def get_text_halo_blur(
        text_format: QgsTextFormat,
        label_settings: QgsPalLayerSettings = None,
    ) -> Union[float, List]:
        """Return ``text-halo-blur`` in pixels.

        QGIS exposes a separate buffer blur radius via ``blurRadius`` when
        available; otherwise half the buffer size is used as a sensible
        approximation. Honours the data-defined ``BufferBlurRadius``
        override on ``label_settings`` when the QGIS build supports it.
        """
        buffer = text_format.buffer()
        if not buffer.enabled():
            return 0
        try:
            blur = buffer.blurRadius()
            if blur is not None:
                base_blur = PropertyExtractor.convert_length_to_pixels(
                    blur, buffer.blurRadiusUnit()
                )
            else:
                base_blur = buffer.size() * 0.5
        except (AttributeError, RuntimeError):
            base_blur = buffer.size() * 0.5

        if label_settings is None:
            return base_blur
        try:
            prop_key = getattr(QgsPalLayerSettings, "BufferBlurRadius")
        except AttributeError:
            return base_blur
        try:
            blur_prop = label_settings.dataDefinedProperties().property(prop_key)
            return PropertyExtractor.get_value_or_expression(base_blur, blur_prop)
        except (AttributeError, RuntimeError):
            return base_blur

    @staticmethod
    def get_text_anchor(label_settings: QgsPalLayerSettings) -> str:
        """Return ``text-anchor`` mapped from the QGIS quadrant offset."""
        anchor_map = {
            0: "bottom-right", 1: "bottom",  2: "bottom-left",
            3: "right",        4: "center",  5: "left",
            6: "top-right",    7: "top",     8: "top-left",
        }
        return anchor_map.get(PropertyExtractor.enum_int(label_settings.quadOffset), "center")

    @staticmethod
    def get_text_justify(label_settings: QgsPalLayerSettings) -> Union[str, List]:
        """Return ``text-justify`` mapped from the multi-line alignment setting.

        Honours a data-defined ``MultiLineAlignment`` override when active.
        For field-based overrides the source attribute is expected to
        contain the literal MapLibre keyword (``"left"``, ``"center"``,
        ``"right"`` or ``"auto"``); QGIS-specific integer/string codes are
        not translated server-side.
        """
        try:
            justification = label_settings.multiLineAlignment
        except AttributeError:
            try:
                justification = label_settings.alignment
            except AttributeError:
                justification = 1
        justify_map = {0: "left", 1: "center", 2: "right", 3: "center"}
        base_justify = justify_map.get(PropertyExtractor.enum_int(justification), "left")
        try:
            justify_prop = label_settings.dataDefinedProperties().property(
                QgsPalLayerSettings.Property.MultiLineAlignment
            )
            return PropertyExtractor.get_value_or_expression(base_justify, justify_prop)
        except (AttributeError, RuntimeError):
            return base_justify

    # QGIS's "Offset from point" placement, the only one that uses xOffset/yOffset.
    _OVER_POINT = 1

    @staticmethod
    def get_text_offset(label_settings: QgsPalLayerSettings) -> List[float]:
        """Return ``text-offset`` ``[x, y]`` in ems (y down, as in QGIS)."""
        if PropertyExtractor.enum_int(label_settings.placement) != TextPropertyExtractor._OVER_POINT:
            return [0, 0]
        x_offset = label_settings.xOffset
        y_offset = label_settings.yOffset
        if x_offset != 0 or y_offset != 0:
            offset_unit = PropertyExtractor.get_attribute(label_settings, "offsetUnits")
            em = TextPropertyExtractor.get_text_size_px(label_settings.format())
            return [
                PropertyExtractor.convert_length_to_pixels(x_offset, offset_unit) / em,
                PropertyExtractor.convert_length_to_pixels(y_offset, offset_unit) / em,
            ]
        return [0, 0]

    @staticmethod
    def get_text_radial_offset(label_settings: QgsPalLayerSettings) -> float:
        """Return ``text-radial-offset`` in pixels from the label distance setting.

        Used in combination with ``text-variable-anchor`` to position labels
        radially around an anchor point.
        """
        try:
            label_settings.dist
        except AttributeError:
            return 0
        return 0.7
        # if not distance:
        #     return 0
        # unit = PropertyExtractor.get_attribute(label_settings, "distUnits", "distUnit")
        # return PropertyExtractor.convert_length_to_pixels(distance, unit)

    @staticmethod
    def get_text_variable_anchor() -> Optional[List[str]]:
        """Return ``text-variable-anchor`` when QGIS uses a flexible placement.

        For ``AroundPoint`` (0) and ``OrderedPositionsAroundPoint`` (6), a
        list of candidate anchors is emitted so the renderer can pick the
        best fit. ``None`` is returned otherwise so MapLibre falls back to
        the static ``text-anchor`` value.
        """
        return ["bottom",  "bottom-left", "bottom-right", "left", "right", "top", "top-left", "top-right"]

    @staticmethod
    def get_text_max_angle(label_settings: QgsPalLayerSettings) -> float:
        """Return ``text-max-angle`` in degrees for curved-label placement.

        Sourced from ``maxCurvedCharAngleIn`` (with a fallback to
        ``maxCurvedCharAngleOut``); MapLibre defaults to 45° when omitted.
        """
        try:
            angle_in = label_settings.maxCurvedCharAngleIn
            if angle_in is not None:
                return abs(float(angle_in))
        except (AttributeError, RuntimeError, TypeError):
            pass
        try:
            angle_out = label_settings.maxCurvedCharAngleOut
            if angle_out is not None:
                return abs(float(angle_out))
        except (AttributeError, RuntimeError, TypeError):
            pass
        return 45.0

    @staticmethod
    def get_text_allow_overlap(label_settings: QgsPalLayerSettings = None) -> bool:
        """Return ``text-allow-overlap``: QGIS's "Allow overlaps without penalty"."""
        try:
            handling = label_settings.placementSettings().overlapHandling()
            return PropertyExtractor.enum_int(handling) == PropertyExtractor.enum_int(
                Qgis.LabelOverlapHandling.AllowOverlapAtNoCost
            )
        except (AttributeError, RuntimeError):
            return False

    @staticmethod
    def get_text_ignore_placement() -> bool:
        """Return ``text-ignore-placement`` (MapLibre default: ``False``)."""
        return False

    @staticmethod
    def get_text_optional() -> bool:
        """Return ``text-optional`` (MapLibre default: ``False``)."""
        return False

    @staticmethod
    def get_text_padding() -> float:
        """Return ``text-padding`` in pixels (MapLibre default: 2).

        QGIS lets labels touch, so the default keeps about as many labels.
        """
        return 2

    @staticmethod
    def get_text_line_height(text_format: QgsTextFormat = None) -> float:
        """Return ``text-line-height`` in ems.

        QGIS's line height is a multiple of the font's own line spacing,
        about 1.2 em: MapLibre's default.
        """
        try:
            if PropertyExtractor.enum_int(text_format.lineHeightUnit()) == PropertyExtractor.enum_int(
                Qgis.RenderUnit.Percentage
            ):
                return 1.2 * text_format.lineHeight()
        except (AttributeError, RuntimeError, TypeError):
            pass
        return 1.2

    @staticmethod
    def get_text_letter_spacing() -> float:
        """Return ``text-letter-spacing`` in ems (default 0)."""
        return 0

    @staticmethod
    def get_text_transform(label_settings: QgsPalLayerSettings = None) -> str:
        """Return ``text-transform`` (``"none"``, ``"uppercase"``, or ``"lowercase"``).

        Maps from the QGIS capitalisation setting when available.
        """
        if label_settings is None:
            return "none"
        try:
            cap = PropertyExtractor.get_attribute(
                label_settings.format(), "capitalization"
            )
        except (AttributeError, RuntimeError):
            return "none"
        # QgsStringUtils::Capitalization: 1=AllUppercase, 2=AllLowercase
        if cap == 1:
            return "uppercase"
        if cap == 2:
            return "lowercase"
        return "none"

    @staticmethod
    def get_text_max_width(label_settings: QgsPalLayerSettings) -> float:
        """Return ``text-max-width`` in ems.

        QGIS's ``autoWrapLength`` counts characters; an average character is
        about half an em wide. Without it, a very large value effectively
        disables wrapping.
        """
        if label_settings.autoWrapLength > 0:
            return label_settings.autoWrapLength * 0.5
        return 999

    @staticmethod
    def get_text_keep_upright() -> bool:
        """Return ``text-keep-upright`` (default ``True``)."""
        return True

    @staticmethod
    def get_text_rotate(label_settings: QgsPalLayerSettings) -> Union[float, List]:
        """Return ``text-rotate`` in degrees, honouring data-defined overrides."""
        base_rotation = label_settings.angleOffset if label_settings.angleOffset != 0 else 0
        rotation_prop = label_settings.dataDefinedProperties().property(
            QgsPalLayerSettings.Property.LabelRotation
        )
        return PropertyExtractor.get_value_or_expression(base_rotation, rotation_prop)

    @staticmethod
    def get_text_rotation_alignment() -> str:
        """Return ``text-rotation-alignment`` (default ``"map"``)."""
        return "map"

    @staticmethod
    def get_text_pitch_alignment() -> str:
        """Return ``text-pitch-alignment`` (default ``"viewport"``)."""
        return "viewport"

    @staticmethod
    def get_text_translate() -> List[float]:
        """Return ``text-translate`` ``[x, y]`` offset in pixels (default ``[0, 0]``)."""
        return [0, 0]

    @staticmethod
    def get_text_translate_anchor() -> str:
        """Return ``text-translate-anchor`` (MapLibre default: ``"map"``)."""
        return "map"


class QgisMapLibreStyleExporter:
    """Export QGIS Vector Tile Layer styles to a MapLibre GL style JSON.

    Walks a ``QgsVectorTileLayer``'s renderer and labelling, converting each
    style entry into the appropriate MapLibre layer (``fill``, ``line``,
    ``symbol``, etc.). Marker symbols and label background markers are
    registered with an internal sprite registry so the companion
    ``SpriteGenerator`` can render them as a sprite sheet alongside the
    emitted ``style.json``.
    """

    def __init__(
        self,
        output_dir: str,
        utils_dir,
        layer: Optional[QgsVectorTileLayer] = None,
        viewer: int = 0,
        minzoom: int = 0,
        maxzoom: int = 14

    ):
        """Initialise the exporter.

        Args:
            output_dir:      Directory where ``style.json`` and the sprite
                             folder will be written.
            layer:           The vector tile layer to export. If ``None``,
                             the active layer in the QGIS interface is used.
        """
        self.output_dir = output_dir
        self.utils_dir = utils_dir
        self.marker_symbols: dict = {}
        self.marker_counter = 0
        self.glyphs = {}
        self.viewer = viewer
        self.minzoom = minzoom
        self.maxzoom = maxzoom
        self.layer = self._resolve_layer(layer)
        self.source_name = "q2vt_tiles"
        self.style = self._build_style_skeleton()
        self.style["layers"].append(self._build_background_layer())

    def _resolve_layer(self, layer: Optional[QgsVectorTileLayer]) -> QgsVectorTileLayer:
        """Return ``layer`` or fall back to the active QGIS layer.

        Raises:
            ValueError: If no layer is supplied and no active layer exists,
                        or if the resolved layer is not a ``QgsVectorTileLayer``.
        """
        if layer is None:
            try:
                if iface and iface.activeLayer():
                    layer = iface.activeLayer()
                else:
                    raise ValueError("No active layer found and no layer provided")
            except (ImportError, ValueError) as e:
                raise e
        if not isinstance(layer, QgsVectorTileLayer):
            raise ValueError(f"Layer must be a QgsVectorTileLayer, got {type(layer).__name__}")
        return layer

    def _build_style_skeleton(self) -> dict:
        """Build the empty MapLibre style document with sources and sprite refs."""
        return {
            "version": 8,
            "name": f"{self.source_name}_style",
            "sources": {
                self.source_name: {
                    "type": "vector",
                    "tiles": ["http://localhost:9000/tiles/tiles/{z}/{x}/{y}.pbf?v=10031993"],
                    # The highest zoom with tiles; viewers enlarge its tiles
                    # beyond it rather than request tiles that don't exist.
                    "maxzoom": max(0, min(self.maxzoom, _TILES_MAX_ZOOM)),
                }
            },
            "glyphs": "http://localhost:9000/style/glyphs/{fontstack}/{range}.pbf",
            "sprite": "http://localhost:9000/style/sprite/sprite",
            "layers": [],
        }

    def _build_background_layer(self) -> dict:
        """The style's bottom layer: the project's background colour.

        The viewers show a basemap (OpenStreetMap, NASA Blue Marble) above
        it from their own basemap switcher.
        """
        bg_color = PropertyExtractor.convert_qcolor_to_maplibre(
            QgsProject.instance().backgroundColor()
        )
        return {
            "id": "background", "type": "background", "minzoom": 0, "maxzoom": 22,
            "paint": {"background-color": bg_color},
        }

    def export(self) -> Dict[str, Any]:
        """Convert all styles and labelling on the layer and write to disk.

        Returns:
            The complete MapLibre style dictionary.
        """
        self.layer.source()
        self._set_map_units()

        renderer = self.layer.renderer()
        if isinstance(renderer, QgsVectorTileBasicRenderer):
            for style in renderer.styles():
                self._convert_renderer_style(style)

        labeling = self.layer.labeling()
        if isinstance(labeling, QgsVectorTileBasicLabeling):
            for style in labeling.styles():
                self._convert_labeling_style(style)

        self.save_to_file()
        return self.style

    def _set_map_units(self) -> None:
        """Size map-unit lengths for the project's CRS at the tiles' latitude."""
        latitude = 0.0
        try:
            extent = self.layer.extent()
            if not extent.isEmpty():
                to_wgs84 = QgsCoordinateTransform(
                    self.layer.crs(), QgsCoordinateReferenceSystem("EPSG:4326"), QgsProject.instance()
                )
                latitude = to_wgs84.transform(extent.center()).y()
        except (QgsCsException, RuntimeError, AttributeError):  # Equator sizes then.
            latitude = 0.0
        PropertyExtractor.set_map_units(QgsProject.instance().crs(), latitude)

    def _convert_renderer_style(self, style):
        """Convert a single ``QgsVectorTileBasicRendererStyle`` into MapLibre layer(s)."""
        if not style.isEnabled() or not style.symbol():
            return
        min_zoom = style.minZoomLevel()
        max_zoom = style.maxZoomLevel() + 1 
        # if self.viewer == 0:
        #     min_zoom = style.minZoomLevel()
        #     max_zoom = style.maxZoomLevel() + 1 
        # else:
        #     min_zoom = style.minZoomLevel() - 1
        #     max_zoom = min(style.maxZoomLevel() + 1, self.maxzoom)
        self._convert_symbol(
            style.symbol(), style.styleName(), style.layerName(),
            self.source_name, min_zoom, max_zoom,
        )

    def _convert_labeling_style(self, style):
        """Convert a single ``QgsVectorTileBasicLabelingStyle`` into a MapLibre symbol layer."""
        if not style.isEnabled() or not style.labelSettings():
            return
        min_zoom = style.minZoomLevel()
        max_zoom = style.maxZoomLevel() + 1 
        # if self.viewer == 0:
        #     min_zoom = style.minZoomLevel()
        #     max_zoom = style.maxZoomLevel() + 1 
        # else:
        #     min_zoom = style.minZoomLevel() - 1
        #     max_zoom = min(style.maxZoomLevel() + 1, self.maxzoom)
        self._convert_label(
            style.labelSettings(), style.styleName(), style.layerName(),
            self.source_name, min_zoom, max_zoom,
        )

    def _convert_symbol(
        self,
        symbol: QgsSymbol,
        style_name: str,
        source_layer_name: str,
        source_name: str,
        min_zoom: int = -1,
        max_zoom: int = -1,
    ):
        """Dispatch a QGIS symbol to the correct conversion routine by symbol type."""
        if symbol.symbolLayerCount() == 0:
            return
        symbol_layer = symbol.symbolLayer(0)
        symbol_type = symbol.type()

        if symbol_type == QgsSymbol.SymbolType.Marker:
            self._convert_marker_symbol(
                symbol_layer, symbol, style_name, source_layer_name,
                source_name, min_zoom, max_zoom,
            )
        elif symbol_type == QgsSymbol.SymbolType.Line:
            self._convert_line_symbol(
                symbol, style_name, source_layer_name, source_name, min_zoom, max_zoom
            )
        elif symbol_type == QgsSymbol.SymbolType.Fill:
            self._convert_fill_symbol(
                symbol_layer, symbol, style_name, source_layer_name, source_name, min_zoom, max_zoom
            )

    def _base_layer_def(
        self,
        layer_type: str,
        style_name: str,
        source_layer_name: str,
        source_name: str,
        min_zoom: int,
        max_zoom: int,
    ) -> dict:
        """Build a common MapLibre layer-definition skeleton with id/source/zoom range."""
        layer_def: dict = {
            "id": style_name,
            "type": layer_type,
            "source": source_name,
            "source-layer": source_layer_name,
            "paint": {},
            "layout": {},
        }
        if min_zoom >= 0:
            layer_def["minzoom"] = min_zoom
        if max_zoom >= 0:
            layer_def["maxzoom"] = max_zoom
        return layer_def

    def _register_pattern(self, symbol_or_layer) -> str:
        """Register a pattern image (or sub-symbol) in the sprite registry.

        Used by line/fill pattern conversion. Returns the unique pattern name
        the MapLibre layer should reference via ``line-pattern`` or
        ``fill-pattern``.
        """
        pattern_name = f"pattern_{self.marker_counter}"
        self.marker_counter += 1
        try:
            symbol_or_layer = symbol_or_layer.clone()
        except (AttributeError, RuntimeError):
            pass
        if FillPropertyExtractor.is_pattern_fill(symbol_or_layer):
            width, height = FillPropertyExtractor.get_pattern_tile_size(symbol_or_layer)
            symbol_or_layer = FillPattern(symbol_or_layer, width, height)
        self.marker_symbols[pattern_name] = symbol_or_layer
        return pattern_name

    def _convert_marker_symbol(
        self,
        symbol_layer: QgsSymbolLayer,
        symbol: QgsSymbol,
        style_name: str,
        source_layer_name: str,
        source_name: str,
        min_zoom: int = -1,
        max_zoom: int = -1,
    ):
        """Convert a QGIS marker symbol into a MapLibre ``symbol`` layer."""
        layer_def = self._base_layer_def(
            "symbol", style_name, source_layer_name, source_name, min_zoom, max_zoom
        )

        marker_name = f"marker_{self.marker_counter}"
        self.marker_counter += 1
        self.marker_symbols[marker_name] = symbol.clone()

        layer_def["layout"].update({
            "icon-image": IconPropertyExtractor.get_icon_image(marker_name),
            "icon-size": IconPropertyExtractor.get_icon_size(symbol_layer, 1.0),
            "icon-rotate": IconPropertyExtractor.get_icon_rotate(symbol_layer=symbol_layer),
            "icon-padding": IconPropertyExtractor.get_icon_padding(),
            "icon-rotation-alignment": IconPropertyExtractor.get_icon_rotation_alignment(),
            "icon-pitch-alignment": IconPropertyExtractor.get_icon_pitch_alignment(),
            "icon-anchor": IconPropertyExtractor.get_icon_anchor(),
            "icon-allow-overlap": IconPropertyExtractor.get_icon_allow_overlap(True),
            "icon-ignore-placement": IconPropertyExtractor.get_icon_ignore_placement(),
            "icon-optional": IconPropertyExtractor.get_icon_optional(),
            "icon-keep-upright": IconPropertyExtractor.get_icon_keep_upright(),
            "symbol-placement": IconPropertyExtractor.get_symbol_placement(),
            "symbol-spacing": IconPropertyExtractor.get_symbol_spacing(),
            "symbol-avoid-edges": IconPropertyExtractor.get_symbol_avoid_edges(),
            "symbol-sort-key": IconPropertyExtractor.get_symbol_sort_key(),
            "symbol-z-order": IconPropertyExtractor.get_symbol_z_order(),
            "visibility": "visible",
        })
        layer_def["paint"].update({
            "icon-opacity": IconPropertyExtractor.get_icon_opacity(),
            "icon-halo-color": IconPropertyExtractor.get_icon_halo_color(),
            "icon-halo-width": IconPropertyExtractor.get_icon_halo_width(),
            "icon-halo-blur": IconPropertyExtractor.get_icon_halo_blur(),
            "icon-translate": IconPropertyExtractor.get_icon_translate(),
            "icon-translate-anchor": IconPropertyExtractor.get_icon_translate_anchor(),
        })

        self.style["layers"].append(layer_def)

    def _convert_line_symbol(
        self,
        symbol: QgsSymbol,
        style_name: str,
        source_layer_name: str,
        source_name: str,
        min_zoom: int = -1,
        max_zoom: int = -1,
    ):
        """Convert every symbol layer of a QGIS line symbol into MapLibre layer(s).

        A QGIS line symbol can stack multiple symbol layers - typically a
        base ``QgsSimpleLineSymbolLayer`` stroke plus one or more
        ``QgsMarkerLineSymbolLayer`` marker decorations. Each sub-layer is
        converted independently and appended to ``self.style["layers"]`` in
        the same bottom-to-top order QGIS uses for its symbol layers, so
        marker decorations correctly render above or below the base stroke
        exactly as they do in QGIS.
        """
        for index in range(symbol.symbolLayerCount()):
            symbol_layer = symbol.symbolLayer(index)
            # The first sub-layer keeps the original style name (so existing
            # look-ups by id keep working); subsequent sub-layers get a
            # unique suffixed id since MapLibre layer ids must be unique.
            layer_id = style_name if index == 0 else f"{style_name}_layer{index}"

            if LinePropertyExtractor.is_marker_line(symbol_layer):
                self._convert_marker_line_symbol_layer(
                    symbol_layer, layer_id, source_layer_name, source_name,
                    min_zoom, max_zoom,
                )
            else:
                self._convert_simple_or_pattern_line_symbol_layer(
                    symbol_layer, symbol, layer_id, source_layer_name, source_name,
                    min_zoom, max_zoom,
                )

    def _convert_marker_line_symbol_layer(
        self,
        symbol_layer: QgsSymbolLayer,
        style_name: str,
        source_layer_name: str,
        source_name: str,
        min_zoom: int = -1,
        max_zoom: int = -1,
    ):
        """Convert a QGIS ``QgsMarkerLineSymbolLayer`` into a MapLibre ``symbol`` layer.

        The marker line's sub-symbol is rendered to a sprite (registered via
        ``self.marker_symbols`` exactly like a standalone marker symbol) and
        referenced through ``icon-image``. QGIS's interval/vertex placement
        is mapped to ``symbol-placement``/``symbol-spacing``,
        ``rotateSymbols()`` controls ``icon-rotation-alignment``, and the
        marker line's perpendicular ``offset()`` is reproduced via
        ``icon-offset`` so markers displaced from the line stay displaced
        the same way in MapLibre.
        """
        sub_symbol = None
        try:
            sub_symbol = symbol_layer.subSymbol()
        except (AttributeError, RuntimeError):
            pass
        if sub_symbol is None or sub_symbol.symbolLayerCount() == 0:
            return

        layer_def = self._base_layer_def(
            "symbol", style_name, source_layer_name, source_name, min_zoom, max_zoom
        )

        marker_name = f"marker_{self.marker_counter}"
        self.marker_counter += 1
        self.marker_symbols[marker_name] = sub_symbol.clone()

        marker_sub_layer = sub_symbol.symbolLayer(0)
        rotate_with_line = LinePropertyExtractor.get_marker_line_rotate_symbols(symbol_layer)
        offset_px = LinePropertyExtractor.get_marker_line_offset(symbol_layer)

        layer_def["layout"].update({
            "icon-image": IconPropertyExtractor.get_icon_image(marker_name),
            "icon-size": IconPropertyExtractor.get_icon_size(marker_sub_layer, 1.0),
            "icon-rotate": 0,
            "icon-padding": IconPropertyExtractor.get_icon_padding(),
            # Following the line's bearing ("map") reproduces rotateSymbols()
            # == True; "viewport" keeps markers upright regardless of the
            # line's direction, matching rotateSymbols() == False.
            "icon-rotation-alignment": "map" if rotate_with_line else "viewport",
            "icon-pitch-alignment": IconPropertyExtractor.get_icon_pitch_alignment(),
            "icon-anchor": IconPropertyExtractor.get_icon_anchor(),
            "icon-allow-overlap": IconPropertyExtractor.get_icon_allow_overlap(True),
            # QGIS marker lines stamp every marker unconditionally - there is
            # no collision system in QGIS to reproduce. icon-allow-overlap
            # alone only stops a marker from being hidden by collisions;
            # each repeat along the line is still registered in MapLibre's
            # collision index and will suppress its own later siblings (and
            # be suppressed by them) unless icon-ignore-placement is also
            # true. Both flags together are required to fully disable
            # collision-based hiding, matching QGIS's "always show" look.
            "icon-ignore-placement": True,
            "icon-optional": IconPropertyExtractor.get_icon_optional(),
            "icon-keep-upright": False,
            "symbol-placement": LinePropertyExtractor.get_marker_line_symbol_placement(symbol_layer),
            "symbol-spacing": LinePropertyExtractor.get_marker_line_spacing(symbol_layer),
            "symbol-avoid-edges": IconPropertyExtractor.get_symbol_avoid_edges(),
            "symbol-sort-key": IconPropertyExtractor.get_symbol_sort_key(),
            "symbol-z-order": IconPropertyExtractor.get_symbol_z_order(),
            "visibility": "visible",
        })
        if offset_px:
            # icon-offset is applied in the icon's own pixel space and
            # rotates together with icon-rotate/icon-rotation-alignment, so
            # when the icon follows the line bearing this reproduces QGIS's
            # perpendicular marker-to-line offset.
            icon_size_value = layer_def["layout"]["icon-size"]
            if isinstance(icon_size_value, (int, float)) and icon_size_value:
                compensated_offset = offset_px / icon_size_value
            else:
                # icon-size is data-defined (rare: only when the QGIS marker
                # sub-symbol itself has a per-feature size override). There is
                # no way to build a dynamic two-element icon-offset array in
                # the MapLibre expression language, so fall back to the
                # sprite-quality constant used for the non-data-defined case.
                compensated_offset = offset_px * _SPRITE_QUALITY
            layer_def["layout"]["icon-offset"] = [0, compensated_offset]

        layer_def["paint"].update({
            "icon-opacity": IconPropertyExtractor.get_icon_opacity(),
            "icon-halo-color": IconPropertyExtractor.get_icon_halo_color(),
            "icon-halo-width": IconPropertyExtractor.get_icon_halo_width(),
            "icon-halo-blur": IconPropertyExtractor.get_icon_halo_blur(),
            "icon-translate": IconPropertyExtractor.get_icon_translate(),
            "icon-translate-anchor": IconPropertyExtractor.get_icon_translate_anchor(),
        })

        self.style["layers"].append(layer_def)

    def _convert_simple_or_pattern_line_symbol_layer(
        self,
        symbol_layer: QgsSymbolLayer,
        symbol: QgsSymbol,          # add this
        style_name: str,
        source_layer_name: str,
        source_name: str,
        min_zoom: int = -1,
        max_zoom: int = -1,
    ):
        """Convert a plain-stroke or raster-pattern line symbol layer to MapLibre ``line``."""
        layer_def = self._base_layer_def(
            "line", style_name, source_layer_name, source_name, min_zoom, max_zoom
        )

        if isinstance(symbol_layer, QgsSimpleLineSymbolLayer):
            layer_def["paint"].update({
                "line-color": LinePropertyExtractor.get_line_color(symbol_layer),
                "line-width": LinePropertyExtractor.get_line_width(symbol_layer),
                "line-opacity": LinePropertyExtractor.get_line_opacity(symbol_layer, symbol),
                "line-blur": LinePropertyExtractor.get_line_blur(),
                "line-gap-width": LinePropertyExtractor.get_line_gap_width(),
                "line-translate": LinePropertyExtractor.get_line_translate(),
                "line-translate-anchor": LinePropertyExtractor.get_line_translate_anchor(),
            })

            offset = LinePropertyExtractor.get_line_offset(symbol_layer)
            # Emit offset only when non-zero (preserve compact output) or when
            # the offset is data-defined (a list expression, never numerically zero).
            if isinstance(offset, list) or (isinstance(offset, (int, float)) and offset != 0):
                layer_def["paint"]["line-offset"] = offset

            width_value = layer_def["paint"]["line-width"]
            width_px = width_value if isinstance(width_value, (int, float)) else 1.0
            dasharray = LinePropertyExtractor.get_line_dasharray(symbol_layer, width_px)
            if dasharray:
                layer_def["paint"]["line-dasharray"] = dasharray

            layer_def["layout"].update({
                "line-cap": LinePropertyExtractor.get_line_cap(symbol_layer),
                "line-join": LinePropertyExtractor.get_line_join(symbol_layer),
                "line-miter-limit": LinePropertyExtractor.get_line_miter_limit(),
                "line-round-limit": LinePropertyExtractor.get_line_round_limit(),
                "line-sort-key": LinePropertyExtractor.get_line_sort_key(symbol_layer),
                "visibility": "visible",
            })
        elif LinePropertyExtractor.is_pattern_line(symbol_layer):
            # Raster / pattern-based line: emit line-pattern instead of line-color.
            pattern_name = self._register_pattern(symbol_layer)
            layer_def["paint"]["line-pattern"] = pattern_name
            layer_def["paint"].update({
                "line-opacity": 1.0,
                "line-translate": LinePropertyExtractor.get_line_translate(),
                "line-translate-anchor": LinePropertyExtractor.get_line_translate_anchor(),
            })
            layer_def["layout"].update({
                "line-cap": "round",
                "line-join": "round",
                "line-miter-limit": LinePropertyExtractor.get_line_miter_limit(),
                "line-round-limit": LinePropertyExtractor.get_line_round_limit(),
                "visibility": "visible",
            })

        self.style["layers"].append(layer_def)

    def _convert_fill_symbol(
        self,
        symbol_layer: QgsSymbolLayer,
        symbol: QgsSymbol,          # add this
        style_name: str,
        source_layer_name: str,
        source_name: str,
        min_zoom: int = -1,
        max_zoom: int = -1,
    ):
        """Convert a QGIS fill symbol into a MapLibre ``fill`` layer."""
        layer_def = self._base_layer_def(
            "fill", style_name, source_layer_name, source_name, min_zoom, max_zoom
        )

        if isinstance(symbol_layer, QgsSimpleFillSymbolLayer):
            if symbol_layer.brushStyle() != Qt.BrushStyle.NoBrush:
                layer_def["paint"].update({
                    "fill-color": FillPropertyExtractor.get_fill_color(symbol_layer),
                    "fill-opacity": FillPropertyExtractor.get_fill_opacity(symbol_layer, symbol),
                    "fill-antialias": FillPropertyExtractor.get_fill_antialias(),
                    "fill-translate": FillPropertyExtractor.get_fill_translate(),
                    "fill-translate-anchor": FillPropertyExtractor.get_fill_translate_anchor(),
                })

            else:
                layer_def["paint"].update({
                    "fill-color": "rgba(0, 0, 0, 0.0)"})
            if symbol_layer.strokeStyle() != Qt.PenStyle.NoPen:
                outline_color = FillPropertyExtractor.get_fill_outline_color(symbol_layer)
                if outline_color:
                    layer_def["paint"]["fill-outline-color"] = outline_color

                layer_def["layout"].update({
                    "fill-sort-key": FillPropertyExtractor.get_fill_sort_key(symbol_layer),
                    "visibility": "visible",
                })
        elif FillPropertyExtractor.is_pattern_fill(symbol_layer):
            # Pattern-based fill: emit fill-pattern; fill-color is ignored by MapLibre.
            pattern_name = self._register_pattern(symbol_layer)
            layer_def["paint"].update({
                "fill-pattern": pattern_name,
                "fill-opacity": FillPropertyExtractor.get_fill_opacity(symbol_layer, symbol),
                "fill-antialias": FillPropertyExtractor.get_fill_antialias(),
                "fill-translate": FillPropertyExtractor.get_fill_translate(),
                "fill-translate-anchor": FillPropertyExtractor.get_fill_translate_anchor(),
            })
            layer_def["layout"].update({
                "fill-sort-key": FillPropertyExtractor.get_fill_sort_key(symbol_layer),
                "visibility": "visible",
            })

        self.style["layers"].append(layer_def)

    def _convert_label(
        self,
        label_settings: QgsPalLayerSettings,
        style_name: str,
        source_layer_name: str,
        source_name: str,
        min_zoom: int = -1,
        max_zoom: int = -1,
    ):
        """Convert a ``QgsPalLayerSettings`` into a MapLibre ``symbol`` layer."""
        layer_def = self._base_layer_def(
            "symbol", style_name, source_layer_name, source_name, min_zoom, max_zoom
        )

        text_format = label_settings.format()

        text_field = TextPropertyExtractor.get_text_field(label_settings)
        if text_field:
            layer_def["layout"]["text-field"] = text_field
        font = TextPropertyExtractor.get_text_font(text_format)
        dataset = join(self.utils_dir, f'{source_layer_name}.{_TEMP_RULE_FORMAT}')
        if self.glyphs.get(font):
            self.glyphs[font].append(dataset)
        else:
            self.glyphs[font] = [dataset]
        layer_def["layout"].update({
            "text-font": [font],
            "text-size": TextPropertyExtractor.get_text_size(text_format, label_settings, self.viewer),
            "text-anchor": TextPropertyExtractor.get_text_anchor(label_settings),
            "text-justify": TextPropertyExtractor.get_text_justify(label_settings),
            "text-offset": TextPropertyExtractor.get_text_offset(label_settings),
            "text-allow-overlap": TextPropertyExtractor.get_text_allow_overlap(label_settings),
            "text-ignore-placement": TextPropertyExtractor.get_text_ignore_placement(),
            "text-optional": TextPropertyExtractor.get_text_optional(),
            "text-padding": TextPropertyExtractor.get_text_padding(),
            "text-line-height": TextPropertyExtractor.get_text_line_height(text_format),
            "text-letter-spacing": TextPropertyExtractor.get_text_letter_spacing(),
            "text-transform": TextPropertyExtractor.get_text_transform(label_settings),
            "text-max-width": TextPropertyExtractor.get_text_max_width(label_settings),
            "text-max-angle": TextPropertyExtractor.get_text_max_angle(label_settings),
            "text-keep-upright": TextPropertyExtractor.get_text_keep_upright(),
            "text-rotate": TextPropertyExtractor.get_text_rotate(label_settings),
            "text-rotation-alignment": TextPropertyExtractor.get_text_rotation_alignment(),
            "text-pitch-alignment": TextPropertyExtractor.get_text_pitch_alignment(),
            "symbol-placement": IconPropertyExtractor.get_symbol_placement(label_settings),
            "symbol-spacing": IconPropertyExtractor.get_symbol_spacing(label_settings),
            "symbol-avoid-edges": IconPropertyExtractor.get_symbol_avoid_edges(),
            "symbol-sort-key": IconPropertyExtractor.get_symbol_sort_key(),
            "symbol-z-order": IconPropertyExtractor.get_symbol_z_order(),
            "visibility": "visible",
        })

        # Every placement but "Offset from point" lets QGIS choose the side.
        # MapLibre uses a radial offset instead of text-offset, so it is set
        # only with the variable anchors.
        variable_anchor = TextPropertyExtractor.get_text_variable_anchor()
        if variable_anchor and (
            PropertyExtractor.enum_int(label_settings.placement) != TextPropertyExtractor._OVER_POINT
        ):
            layer_def["layout"]["text-variable-anchor"] = variable_anchor
            layer_def["layout"]["text-radial-offset"] = TextPropertyExtractor.get_text_radial_offset(
                label_settings
            )


        #         "text-halo-blur": TextPropertyExtractor.get_text_halo_blur(
        #     text_format, label_settings
        # ),
        layer_def["paint"].update({
            "text-color": TextPropertyExtractor.get_text_color(text_format, label_settings),
            "text-opacity": TextPropertyExtractor.get_text_opacity(text_format, label_settings),
            "text-halo-color": TextPropertyExtractor.get_text_halo_color(
                text_format, label_settings
            ),
            "text-halo-width": TextPropertyExtractor.get_text_halo_width(text_format, label_settings),
            "text-translate": TextPropertyExtractor.get_text_translate(),
            "text-translate-anchor": TextPropertyExtractor.get_text_translate_anchor(),
        })

        # Deep-copy label settings to avoid mutating the caller's object.
        label_settings = QgsPalLayerSettings(label_settings)
        label_format = QgsTextFormat(label_settings.format())
        background = QgsTextBackgroundSettings(label_format.background())
        if background.markerSymbol():
            background.setMarkerSymbol(background.markerSymbol().clone())
        label_format.setBackground(background)
        label_settings.setFormat(label_format)

        if background.enabled() and background.markerSymbol():
            self._apply_icon_from_background(layer_def, background, style_name)
        else:
            self._apply_default_icon_props(layer_def)

        self.style["layers"].append(layer_def)

    def _apply_icon_from_background(self, layer_def: dict, background, style_name: str):
        """Configure icon layout/paint from a label background marker symbol."""
        try:
            marker = background.markerSymbol() if hasattr(background, "markerSymbol") else None
            if marker and marker.type() == QgsSymbol.SymbolType.Marker:
                marker_name = f"marker_{self.marker_counter}"
                self.marker_counter += 1
                self.marker_symbols[marker_name] = marker.clone()
                layer_def["layout"]["icon-image"] = marker_name
            else:
                layer_def["layout"]["icon-image"] = style_name
        except (RuntimeError, AttributeError):
            layer_def["layout"]["icon-image"] = style_name

        text_fit = IconPropertyExtractor.get_icon_text_fit(background)
        if text_fit:
            layer_def["layout"]["icon-text-fit"] = text_fit

        text_fit_padding = IconPropertyExtractor.get_icon_text_fit_padding(background)
        if text_fit_padding:
            layer_def["layout"]["icon-text-fit-padding"] = text_fit_padding

        layer_def["layout"].update({
            "icon-anchor": IconPropertyExtractor.get_icon_anchor(),
            "icon-rotate": IconPropertyExtractor.get_icon_rotate(background=background),
            "icon-padding": IconPropertyExtractor.get_icon_padding(),
            "icon-rotation-alignment": IconPropertyExtractor.get_icon_rotation_alignment(),
            "icon-pitch-alignment": IconPropertyExtractor.get_icon_pitch_alignment(),
            "icon-allow-overlap": IconPropertyExtractor.get_icon_allow_overlap(),
            "icon-ignore-placement": IconPropertyExtractor.get_icon_ignore_placement(),
            "icon-keep-upright": IconPropertyExtractor.get_icon_keep_upright(),
            "icon-offset": IconPropertyExtractor.get_icon_offset(background),
        })

        try:
            layer_def["paint"].update({
                "icon-opacity": IconPropertyExtractor.get_icon_opacity(background),
                "icon-color": IconPropertyExtractor.get_icon_color(background),
                "icon-halo-color": IconPropertyExtractor.get_icon_halo_color(background),
                "icon-halo-width": IconPropertyExtractor.get_icon_halo_width(background),
                "icon-halo-blur": IconPropertyExtractor.get_icon_halo_blur(),
                "icon-translate": IconPropertyExtractor.get_icon_translate(),
                "icon-translate-anchor": IconPropertyExtractor.get_icon_translate_anchor(),
            })
        except (OSError, RuntimeError):
            pass

    def _apply_default_icon_props(self, layer_def: dict):
        """Apply default icon layout/paint when no background marker is present."""
        layer_def["layout"].update({
            "icon-allow-overlap": IconPropertyExtractor.get_icon_allow_overlap(),
            "icon-ignore-placement": IconPropertyExtractor.get_icon_ignore_placement(),
            "icon-optional": IconPropertyExtractor.get_icon_optional(),
            "icon-padding": IconPropertyExtractor.get_icon_padding(),
        })
        layer_def["paint"].update({
            "icon-opacity": IconPropertyExtractor.get_icon_opacity(),
            "icon-halo-color": IconPropertyExtractor.get_icon_halo_color(),
            "icon-halo-width": IconPropertyExtractor.get_icon_halo_width(),
            "icon-halo-blur": IconPropertyExtractor.get_icon_halo_blur(),
            "icon-translate": IconPropertyExtractor.get_icon_translate(),
            "icon-translate-anchor": IconPropertyExtractor.get_icon_translate_anchor(),
        })

    def to_json(self, indent: int = 2) -> str:
        """Serialise the in-memory style dict to a JSON string."""
        return json.dumps(self.style, indent=indent)

    def save_to_file(self, filename: str = "style.json", indent: int = 2) -> str:
        """Write the style JSON and the sprite sheet to the output directory.

        Args:
            filename: Filename for the JSON file (relative to ``style/``).
            indent:   JSON indentation level for human-readable output.

        Returns:
            The absolute path of the written ``style.json`` file.
        """
        style_dir = os.path.join(self.output_dir, "style")
        os.makedirs(style_dir, exist_ok=True)

        if self.marker_symbols:
            SpriteGenerator(
                self.marker_symbols, style_dir, _SPRITE_QUALITY, False
            ).generate()
        else:
            del self.style["sprite"]
        if self.glyphs:
            glyphs_dir = os.path.join(self.output_dir, "style", "glyphs")
            os.mkdir(glyphs_dir)
            fontstacks = GlyphGenerator(self.glyphs, 'q2vt_label', glyphs_dir).generate()
            self._use_fontstacks(fontstacks)
        else:
             del self.style["glyphs"]
        rounded_style = self.round_numeric_values(self.style)
        filepath = os.path.join(style_dir, filename)
        with open(filepath, "w", encoding="utf8") as f:
            json.dump(rounded_style, f, indent=indent)
        return filepath
    
    def _use_fontstacks(self, fontstacks: Dict[str, str]) -> None:
        """Point each label's text-font at the glyph folder written for it.

        A font without a style name (e.g. "MS Shell Dlg 2 ") would otherwise
        request glyphs from a folder that doesn't exist.
        """
        for layer_def in self.style["layers"]:
            layout = layer_def.get("layout", {})
            fonts = layout.get("text-font")
            if fonts:
                layout["text-font"] = [fontstacks.get(font, font.strip()) for font in fonts]

    def round_numeric_values(self, obj):
        """
        Recursively walk through dict/list values.
        Convert anything numeric-like to float and round to 2 decimals.
        """
        if isinstance(obj, dict):
            return {k: self.round_numeric_values(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [self.round_numeric_values(item) for item in obj]
        if isinstance(obj, bool):
            return obj
        try:
            # Try converting strings, ints, floats, etc.
            num = float(obj)

            # Keep integers as int if possible after rounding. Small values
            # (a map-unit width at zoom 0) keep 3 significant digits instead.
            rounded = round(num, 2) if abs(num) >= 0.1 or num == 0 else float(f"{num:.3g}")
            return int(rounded) if rounded.is_integer() else rounded

        except (ValueError, TypeError):
            # Not numeric → keep original
            return obj



if __name__ == "__console__":
    exporter = QgisMapLibreStyleExporter(output_dir=QgsProcessingUtils.tempFolder())
    output_file = exporter.export()