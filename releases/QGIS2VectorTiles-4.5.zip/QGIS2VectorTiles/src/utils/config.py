"""
config.py

Global constants, configuration loading, and PyQt version-specific imports.
All other modules import shared symbols from here to avoid duplication.
"""

from os.path import join

from qgis.PyQt.QtCore import qVersion
from qgis.core import QgsApplication


# =====================================================================
# PLUGIN PATHS
# Computed from the live QGIS install. Do not hardcode replacements —
# these must stay derived from QgsApplication at import time.
# =====================================================================
_PLUGIN_DIR = join(QgsApplication.qgisSettingsDirPath(), "python", "plugins", "QGIS2VectorTiles")
_RESOURCES = join(_PLUGIN_DIR, "resources")
_SERVER = join(_RESOURCES, "tiles_server.py")

# =====================================================================
# SERVER / NETWORK SETTINGS
# Safe to adjust if you need a different local port.
# =====================================================================
_PORT = 9000


# =====================================================================
# DATA PROCESSING SETTINGS
# Safe to adjust to tune output quality/size vs. processing speed.
# =====================================================================
_EPSG_CRS = 3857                          # Output projection (Web Mercator)
_DATA_SIMPLIFICATION_TOLERANCE = 1        # Geometry simplification, in CRS units
_REMOVE_DUPLICATES_DISTANCE = 300         # Minimum spacing between points, in points
# The QGIS map scale of web zoom 0: a 512 px tile spans the world's
# 40,075,016.69 m (EPSG:3857) at 96 dpi, as the web map shows it. QGIS shows
# the same ground per pixel at that scale, so a rule's scale range starts
# and ends where it does in QGIS, and @map_scale sizes match.
_TOP_SCALE = 40075016.68557849 / 512 * 96 / 0.0254   # 295,829,355.45
_SPRITE_QUALITY = 1                       # Pixel ratio of sprite.png (sprite@2x.png: twice it);
                                          # sprites are drawn at their real size at each ratio
_FIELD_PREFIX = 'q2vt'                    # Field name prefix
# Tile geometry simplification below the highest tile zoom, in tile units
# (a 512 px tile has 4096 units: 8 units = one screen pixel). Half a pixel:
# a zoom's tiles are shown enlarged up to twice, until the next zoom's, so
# lines stay within a pixel of their course (one pixel looked angular on
# curves, enlarged). None at the highest zoom, where viewers enlarge the
# tiles.
_SIMPLIFICATION = 4
# Up to this zoom, twice that (one screen pixel): a world or continent at
# once, whose tiles are the first loaded.
_SIMPLIFICATION_LOW = 8
_SIMPLIFICATION_LOW_ZOOM = 4
_SIMPLIFICATION_MAX_ZOOM = 0
# Largest tile (bytes) and most features per tile. Beyond them GDAL writes a
# tile with less precision or leaves features out; tiles this big already
# load and draw slowly. A zoom level with few tiles over the extent (the
# lowest ones) allows _TILE_VIEW_SIZE spread over them, up to
# _TILE_MAX_SIZE_FEW: a view shows them all at once anyway, and shrinking a
# tile to the limit costs GDAL several more encodings of it and drops data.
_TILE_MAX_SIZE = 1000000
_TILE_MAX_SIZE_FEW = 4000000
_TILE_VIEW_SIZE = 8000000
_TILE_MAX_FEATURES = 500000
# Included Fields parameter: which source fields the tiles (and the search
# index) carry besides the ones the plugin computes (labels, data-defined
# properties).
_FIELDS_REQUIRED = 0                      # None
_FIELDS_ALL = 1                           # Every field
_FIELDS_VISIBLE = 2                       # Fields not hidden in the layer's form or attribute table
_TILES_MAX_ZOOM = 15                      # Highest zoom tiles are made for; viewers
                                          # enlarge them beyond (0.3 m precision)

# =====================================================================
# BASE-LAYER CACHE
# =====================================================================
# Prepared source layers are reused between runs while their source files,
# extent and required fields are unchanged. Set _CACHE_MAX_MB = 0 to disable.
_CACHE_DIR_NAME = "q2vt_cache"            # Folder inside the system temp folder
_CACHE_MAX_MB = 2048                      # Oldest entries are removed beyond this
_CACHE_MAX_AGE_DAYS = 30                  # Entries unused for longer are removed


# =====================================================================
# MAPLIBRE GLYPH (SDF) GENERATION
# =====================================================================
# --- Format constants — fixed by the MapLibre/Mapbox glyph PBF spec. ---
# These are NOT tunable settings. MapLibre GL JS's client-side glyph
# parser hardcodes these exact values; changing them WILL break glyph
# rendering (mismatched image size errors, square/clipped halos, blurry
# text). Do not edit this block.
_GLYPH_RANGE_SIZE = 256        # Codepoints per .pbf range file (spec-fixed)
_MAX_UNICODE = 65535           # Highest codepoint MapLibre's glyph protocol supports
_MAPLIBRE_GLYPH_BORDER = 3     # MapLibre client's fixed glyph border (never changes)
_REFERENCE_EM = 24.0           # MapLibre's internal reference font size, in px
_REFERENCE_BUFFER = 3.0        # Mapbox/MapLibre reference generator (tiny-sdf) buffer default
_REFERENCE_RADIUS = 8.0        # Mapbox/MapLibre reference generator (tiny-sdf) radius default;
                                # also hardcoded client-side as the shader's SDF_PX constant

# --- Derived generation parameters — DO NOT edit individually. ---
# _SDF_RADIUS and _BUFFER are mathematically dependent on _REFERENCE_RADIUS,
# _REFERENCE_BUFFER, and _FONT_RENDER_SIZE above. Changing one without
# recalculating the others reproduces bugs already solved (mismatched
# image size, blurry/rectangular halos). If _FONT_RENDER_SIZE ever needs
# to change, _SDF_RADIUS and _BUFFER must be recomputed using the
# formulas in the comments below — do not just edit the numbers.
_FONT_RENDER_SIZE = 24         # Source rasterization pixel size (= _REFERENCE_EM)
_SDF_CUTOFF = 0.25             # MapLibre/Mapbox spec: outline lands at byte ~192
_SUPERSAMPLE = 4               # Internal antialiasing supersample factor
_SDF_RADIUS = 8.0              # = _REFERENCE_RADIUS * (_FONT_RENDER_SIZE / _REFERENCE_EM)
_BUFFER = 10                   # = ceil(max(_REFERENCE_BUFFER * scale, _SDF_RADIUS + 2, _MAPLIBRE_GLYPH_BORDER))
_SDF_COVERAGE_THRESHOLD = 127  # AA coverage midpoint used to binarize the glyph mask

# =====================================================================
# PyQt VERSION GUARD
# Imports the right Qt5 / Qt6 symbols once, re-exported below.
# =====================================================================

from qgis.PyQt.QtXml import QDomDocument
from qgis.PyQt.QtCore import QVariant, Qt
from qgis.PyQt import sip



__all__ = [
    # Plugin paths
    "_PLUGIN_DIR",
    "_RESOURCES",
    "_SERVER",
    # Server / network
    "_PORT",
    # Data processing
    "_EPSG_CRS",
    "_DATA_SIMPLIFICATION_TOLERANCE",
    "_REMOVE_DUPLICATES_DISTANCE",
    "_TOP_SCALE",
    "_SPRITE_QUALITY",
    "_FIELD_PREFIX",
    "_SIMPLIFICATION",
    "_SIMPLIFICATION_LOW",
    "_SIMPLIFICATION_LOW_ZOOM",
    "_SIMPLIFICATION_MAX_ZOOM",
    "_TILE_MAX_SIZE",
    "_TILE_MAX_SIZE_FEW",
    "_TILE_VIEW_SIZE",
    "_TILE_MAX_FEATURES",
    "_TILES_MAX_ZOOM",
    "_FIELDS_REQUIRED",
    "_FIELDS_ALL",
    "_FIELDS_VISIBLE",
    # Base-layer cache
    "_CACHE_DIR_NAME",
    "_CACHE_MAX_MB",
    "_CACHE_MAX_AGE_DAYS",
    # Glyph generation
    "_GLYPH_RANGE_SIZE",
    "_MAX_UNICODE",
    "_MAPLIBRE_GLYPH_BORDER",
    "_REFERENCE_EM",
    "_REFERENCE_BUFFER",
    "_REFERENCE_RADIUS",
    "_FONT_RENDER_SIZE",
    "_SDF_CUTOFF",
    "_SUPERSAMPLE",
    "_SDF_RADIUS",
    "_BUFFER",
    "_SDF_COVERAGE_THRESHOLD",
    # PyQt re-exports
    "Qt",
    "QDomDocument",
    "QVariant",
    "sip",
]