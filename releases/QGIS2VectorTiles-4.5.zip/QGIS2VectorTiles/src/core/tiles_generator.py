"""
tiles_generator.py

GDALTilesGenerator — builds a multi-layer OGR VRT from the exported
datasets and calls ogr2ogr to produce MVT (Mapbox Vector Tiles) in MBTiles
format, then copies them into the export's single PMTiles file
(pmtiles_writer).

The MVT driver works a run's zoom levels one after another and gains
nothing from GDAL_NUM_THREADS (measured slower), so the zoom levels are
split into parallel ogr2ogr runs, one process each, whose MBTiles are then
merged into one (zoom levels never share a tile). The runs are balanced by
work: the lowest zoom levels share a run, and the costliest are split by
area into strips of tile columns: a strip's run reads only the features
near it, clipped to it, and keeps only its own tiles.

Each run's temporary database, which the driver writes every feature of
every tile to, is kept in memory while the runs' estimated sizes fit in
half the free memory (several times faster than on disk), else on disk.

Depends on: config (for constants only — no custom class dependencies)
"""

import ctypes
import hashlib
import json
import math
import os
import re
import shutil
import sqlite3
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass
from os import cpu_count
from os.path import join, basename
from typing import Dict, List, Optional, Tuple
from uuid import uuid4
from xml.sax.saxutils import escape, quoteattr, unescape
from osgeo import gdal, ogr
from qgis.core import QgsVectorLayer, QgsProcessingFeedback, QgsProcessingUtils

from .pmtiles_writer import mbtiles_to_pmtiles
from ..utils.gdal_tools import gdal_tool, gdal_tool_env
from ..utils.flattened_rule import (
    CLUSTER_SIZE_FIELD, DISPLACEMENT_ANCHOR_FIELD, DISPLACEMENT_RADIUS_FIELD, GROUP_ZOOM_FIELD, TILE_LAYERS_KEY,
    group_of, group_sources,
)
from ..utils.config import (
    _CACHE_DIR_NAME, _CACHE_MAX_AGE_DAYS,
    _EPSG_CRS, _FIELD_PREFIX, _SIMPLIFICATION, _SIMPLIFICATION_LOW, _SIMPLIFICATION_LOW_ZOOM,
    _SIMPLIFICATION_MAX_ZOOM, _TILES_MAX_ZOOM,
    _TILE_MAX_FEATURES, _TILE_MAX_SIZE, _TILE_MAX_SIZE_FEW, _TILE_VIEW_SIZE,
)

_CREATE_NO_WINDOW = 0x08000000

# Half the width of the EPSG:3857 world, in metres.
_WORLD_HALF = 20037508.342789244

# A run's temporary database in memory takes about this many times the size
# of the datasets it reads, per zoom level (measured: 3.3).
_MEMORY_PER_DATASET_BYTE = 4

# Share of the free memory the runs' in-memory databases may take together.
_MEMORY_SHARE = 0.5

# A tile's width in screen pixels (MapLibre's zoom levels).
_TILE_PIXELS = 512

# Polygons smaller than this share of a screen pixel are left out of the
# tiles below the highest zoom: dense small polygons (parcels, buildings)
# make the lowest zooms' tiles the heaviest, for specks hardly drawn.
_MIN_POLYGON_PIXELS = 0.25

# A zoom level's work per byte of its data: 1, plus this much times the
# square root of its tile count, as features are cut into more tiles
# (fitted on Natural Earth z0-z8 and a city z0-z15, see _plan_runs).
_TILE_COST = 0.017

# Exports reaching this zoom get the finer tile grid (see _fine_grid).
_FINE_GRID_ZOOM = 18
_FINE_GRID_EXTENT = 8192

# Merged lines shorter than this share of a screen pixel are left out below
# the tiles' highest zoom: a line that short is a dot no one sees.
_MIN_LINE_PIXELS = 0.5

# GDAL threads per ogr2ogr process: fewer processes, each multi-threaded,
# shared the CPU better than one thread each (measured on Natural Earth
# z0-8, 12 threads: 4 x 3 took 131 s, 10 x 1 143 s).
_THREADS_PER_RUN = 3

# Tile runs kept between exports (see _cache_path): their output reused
# while every input is unchanged. Size limit in MB.
_TILE_CACHE_MAX_MB = 2048
# Bump when the way runs are built changes.
_TILE_CACHE_VERSION = "1"

# ogr2ogr runs per worker (see _plan_runs). More, smaller runs even out a
# wrong estimate, but each reads and clips its features again: measured on
# Natural Earth and a city, three per worker were slower than one.
_RUNS_PER_WORKER = 1


@dataclass
class _Run:
    """One ogr2ogr run: zoom levels lo..hi, of all tile columns or of
    columns[0]..columns[1] only, written to ``output``."""
    lo: int
    hi: int
    columns: Optional[Tuple[int, int]] = None
    output: str = ""
    in_memory: bool = False
    # Its tile cache entry (see _cache_path); None when not cached.
    cache_path: Optional[str] = None
    from_cache: bool = False
    # Estimated work (see GDALTilesGenerator._plan_runs).
    cost: float = 0.0


class GDALTilesGenerator:
    """Generate MBTiles vector tiles using GDAL CLI with an OGR VRT intermediary."""

    def __init__(
        self,
        layers: List[QgsVectorLayer],
        style: dict,
        output_dir: str,
        extent,
        cpu_percent: int,
        feedback: QgsProcessingFeedback,
    ):
        self.layers = layers
        self.style = style
        self.output_dir = output_dir
        self.extent = extent
        self.cpu_percent = cpu_percent
        self.feedback = feedback
        # Set by cancel(), from another thread.
        self._cancelled = threading.Event()

    def cancel(self):
        """Stop generating (from another thread): the runs are stopped and
        generate() raises."""
        self._cancelled.set()

    def generate(self) -> Tuple[str, int]:
        """Build the VRTs, run ogr2ogr, return (PMTiles path, min_zoom).

        The runs write MBTiles (which merge cheaply), copied at the end into
        the export's one PMTiles file.
        """
        pmtiles = join(self.output_dir, "tiles.pmtiles")
        output = join(QgsProcessingUtils.tempFolder(), f"tiles_{uuid4().hex}.mbtiles")
        try:
            min_zoom = self._generate_mbtiles(output)
            if self._cancelled.is_set() or (self.feedback is not None and self.feedback.isCanceled()):
                raise RuntimeError("Tile generation cancelled.")
            mbtiles_to_pmtiles(output, pmtiles)
        finally:
            self._remove(output)
        return pmtiles, min_zoom

    def _generate_mbtiles(self, output: str) -> int:
        """Make the tiles into the MBTiles ``output``; returns min_zoom."""
        min_zoom = self._get_global_min_zoom()
        max_zoom = self._get_global_max_zoom()
        first = min(min_zoom, _TILES_MAX_ZOOM)
        last = min(max_zoom, _TILES_MAX_ZOOM)
        self._last_zoom = last
        workers = self._worker_count()
        runs = self._plan_runs(first, last, workers)
        self._place_temporary_dbs(runs)
        if len(runs) == 1:
            runs[0].output = output
            self._run_ogr2ogr_runs(runs)
        else:
            for run in runs:
                run.output = join(
                    QgsProcessingUtils.tempFolder(), f"tiles_{run.lo}_{run.hi}_{uuid4().hex}.mbtiles"
                )
            try:
                self._run_ogr2ogr_runs(runs)
                self._merge(output, runs, first, last)
            finally:
                for run in runs:
                    self._remove(run.output)
        return min_zoom

    def _worker_count(self) -> int:
        return max(1, int((cpu_count() or 1) * self.cpu_percent / 100))

    # --- Tile grid over the extent ---

    @staticmethod
    def _tile_index(coordinate: float, zoom: int) -> int:
        """The tile column (or row from the south) holding an EPSG:3857
        coordinate."""
        tiles = 2 ** zoom
        index = int(math.floor((coordinate + _WORLD_HALF) / (2 * _WORLD_HALF) * tiles))
        return min(max(index, 0), tiles - 1)

    def _tile_range(self, zoom: int) -> Tuple[int, int, int, int]:
        """(first column, last column, first row, last row) of the tiles
        covering the extent; the whole world without one."""
        e = self.extent
        if e is None or e.isEmpty():
            return 0, 2 ** zoom - 1, 0, 2 ** zoom - 1
        return (self._tile_index(e.xMinimum(), zoom), self._tile_index(e.xMaximum(), zoom),
                self._tile_index(e.yMinimum(), zoom), self._tile_index(e.yMaximum(), zoom))

    def _tile_count(self, zoom: int) -> int:
        c0, c1, r0, r1 = self._tile_range(zoom)
        return (c1 - c0 + 1) * (r1 - r0 + 1)

    def _max_tile_size(self, zoom: int) -> int:
        """MAX_SIZE of a run whose last zoom level is ``zoom``."""
        return max(_TILE_MAX_SIZE, min(_TILE_MAX_SIZE_FEW, _TILE_VIEW_SIZE // self._tile_count(zoom)))

    # --- Planning the parallel runs ---

    def _plan_runs(self, first: int, last: int, workers: int) -> List[_Run]:
        """The ogr2ogr runs, about _RUNS_PER_WORKER per worker, of about
        equal work each, by estimate (_run_processes starts the largest
        first, and the others as workers finish).

        A zoom level's work is estimated from its datasets' size, more per
        byte the more tiles it has (_TILE_COST): a city's zoom levels cost
        about the same (its features are small next to the tiles, each
        written about once), the world's grow with the zoom (an ocean is
        cut into every tile). The lowest zoom levels share runs, and a zoom level
        costing more than a run's share is split into strips of tile
        columns. The estimate is rough: measured, a byte costs from one to
        twenty times more, with the features' size. The old one run per
        zoom level left most workers idle while Natural Earth's z8 took
        four minutes.
        """
        zooms = [z for z in range(first, last + 1) if self._run_layers(z, z)]
        if workers <= 1 or len(zooms) == 0:
            return [_Run(first, last)]
        cost = {}
        for z in zooms:
            # A dataset in the tiles of the zoom below its own (see
            # _layer_zooms) costs there about what it does in a quarter as
            # many tiles; counted whole, it would leave the highest zoom
            # levels' share too large, in fewer strips run in parallel.
            data = sum(self._dataset_size(layer) * (0.25 if z < self._parse_layer_zoom(layer, "o") else 1)
                       for layer, _, _ in self._run_layers(z, z).values())
            cost[z] = max(data, 1) * (1 + _TILE_COST * math.sqrt(self._tile_count(z)))
        share = sum(cost.values()) / (workers * _RUNS_PER_WORKER)
        plan: List[list] = []  # [lo, hi, strips, cost]
        group: List[int] = []

        def close_group():
            if group:
                plan.append([group[0], group[-1], 1, sum(cost[z] for z in group)])
                group.clear()

        for z in zooms:
            if cost[z] >= share:
                close_group()
                c0, c1, _, _ = self._tile_range(z)
                plan.append([z, z, max(1, min(c1 - c0 + 1, round(cost[z] / share))), cost[z]])
                continue
            if group and sum(cost[g] for g in group) + cost[z] > share:
                close_group()
            group.append(z)
        close_group()
        runs = []
        for lo, hi, strips, work in plan:
            if strips == 1:
                runs.append(_Run(lo, hi, cost=work))
                continue
            c0, c1, _, _ = self._tile_range(hi)
            total = c1 - c0 + 1
            start = c0
            for i in range(strips):
                width = total // strips + (1 if i < total % strips else 0)
                runs.append(_Run(lo, hi, (start, start + width - 1), cost=work * width / total))
                start += width
        return runs

    def _strip_filter(self, run: _Run) -> List[str]:
        """ogr2ogr's spatial filter for a strip: its columns, widened by a
        tile on each side so that every feature reaching into its tiles
        (or their buffer) is read; nothing for a whole run. Features are
        also clipped to it: the driver writes a feature to every tile it
        reaches, so an ocean or a continent read whole would be cut into
        every tile of the world by every strip."""
        if run.columns is None:
            return []
        tile = 2 * _WORLD_HALF / 2 ** run.hi
        west = -_WORLD_HALF + run.columns[0] * tile - tile
        east = -_WORLD_HALF + (run.columns[1] + 1) * tile + tile
        return ["-spat", repr(west), repr(-_WORLD_HALF), repr(east), repr(_WORLD_HALF),
                "-clipsrc", "spat_extent"]

    # --- Temporary databases ---

    def _place_temporary_dbs(self, runs: List[_Run]):
        """Keep runs' temporary databases in memory while their estimated
        sizes fit in _MEMORY_SHARE of the free memory."""
        budget = self._free_memory() * _MEMORY_SHARE
        sizes = {}
        for run in runs:
            layers = self._run_layers(run.lo, run.hi)
            data = sum(self._dataset_size(layer) for layer, _, _ in layers.values())
            strips = 1
            if run.columns is not None:
                c0, c1, _, _ = self._tile_range(run.hi)
                strips = max(1, (c1 - c0 + 1) / (run.columns[1] - run.columns[0] + 1))
            sizes[id(run)] = _MEMORY_PER_DATASET_BYTE * data * (run.hi - run.lo + 1) / strips
        for run in sorted(runs, key=lambda r: sizes[id(r)]):
            if sizes[id(run)] <= budget:
                run.in_memory = True
                budget -= sizes[id(run)]

    @staticmethod
    def _dataset_size(layer: QgsVectorLayer) -> int:
        try:
            return os.path.getsize(layer.source().split("|")[0])
        except OSError:
            return 0

    @staticmethod
    def _free_memory() -> int:
        """Free physical memory in bytes; 0 if unknown."""
        try:
            if os.name == "nt":
                class _MemoryStatus(ctypes.Structure):
                    _fields_ = [
                        ("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                    ]
                status = _MemoryStatus()
                status.dwLength = ctypes.sizeof(status)
                if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                    return int(status.ullAvailPhys)
                return 0
            return os.sysconf("SC_AVPHYS_PAGES") * os.sysconf("SC_PAGE_SIZE")
        except (AttributeError, OSError, ValueError):
            return 0

    # --- Per-layer zoom configuration ---

    def _layer_zooms(self, layer: QgsVectorLayer) -> Tuple[int, int]:
        """The layer's tile zoom range. Tiles stop at _TILES_MAX_ZOOM, where
        viewers enlarge them, so a layer shown only beyond it is written to
        that zoom's tiles.

        Lines, fills and labels are also written to the tiles of the zoom
        below their own: while a zoom's tiles load, MapLibre draws the tiles
        it has from the zoom below in their place, which then hold them too
        (the style draws them only from their own zoom, see
        bridge_zoom_bands), so the map isn't blank meanwhile. Grouped points
        (clusters, displaced points) are grouped for each zoom: not them."""
        low = self._parse_layer_zoom(layer, "o")
        kind = (self._parse_layer_zoom(layer, "t"), self._parse_layer_zoom(layer, "c"))
        if kind[0] == 1 or kind in ((0, 1), (0, 2)):
            if not hasattr(self, "_first_zoom"):
                self._first_zoom = self._get_global_min_zoom()
                self._grouped = self._group_sources()
            if self._group_of(self._layer_name(layer), self._grouped) is None:
                low = max(low - 1, self._first_zoom)
        return (min(low, _TILES_MAX_ZOOM),
                min(self._parse_layer_zoom(layer, "i"), _TILES_MAX_ZOOM))

    def _run_layers(self, lo: int, hi: int) -> Dict[str, Tuple[QgsVectorLayer, int, int]]:
        """The layers a run of zooms lo..hi writes, with their zoom range
        within it. A layer not configured for a run would be written at all
        its zooms, so each run gets only its own layers."""
        result = {}
        for layer in self.layers:
            minzoom, maxzoom = self._layer_zooms(layer)
            if minzoom <= hi and maxzoom >= lo:
                result[self._layer_name(layer)] = (layer, max(minzoom, lo), min(maxzoom, hi))
        return result

    @staticmethod
    def _entries(run_layers: dict) -> List[tuple]:
        """A run's VRT layers: (dataset, entry name, minzoom, maxzoom).

        (Measured on Natural Earth z0-8, 16 Nov 2026: simplifying the
        stand-in copies further, in entries of their own, cut their raw
        bytes by a tenth but left the gzipped tiles larger: not done.)"""
        return [(layer, name, minzoom, maxzoom) for name, (layer, minzoom, maxzoom) in run_layers.items()]

    def _build_layer_conf(self, conf_path: str, entries: List[tuple], extra: Optional[dict] = None):
        """Write the MVT driver's CONF file: each layer's own zoom range
        (and ``extra`` entries, e.g. a grouped layer's zoom levels, see
        _group_blocks).

        Without it every layer is written to every zoom level of the
        dataset, although each style only shows it within its own range.
        """
        shared = self._shared_tile_layers()
        conf = {}
        for layer, entry_name, minzoom, maxzoom in entries:
            name = self._layer_name(layer)
            entry = conf[entry_name] = {"minzoom": minzoom, "maxzoom": maxzoom}
            target = shared.get(name, name)
            if target != entry_name:
                entry["target_name"] = target
        conf.update(extra or {})
        with open(conf_path, "w", encoding="utf-8") as f:
            json.dump(conf, f)

    def _shared_tile_layers(self) -> Dict[str, str]:
        """By dataset, the tile layer of another dataset it is written into
        (the style draws both as one layer: share_tile_layers)."""
        return (self.style.get("metadata") or {}).get(TILE_LAYERS_KEY, {})

    # --- VRT construction ---

    def _build_vrt(self, vrt_path: str, entries: List[tuple], last_zoom: int = None,
                   extra: str = ""):
        """Write an OGR VRT containing one entry per run entry (see
        _entries), for a run whose last zoom level is ``last_zoom`` (see
        _min_area), and ``extra`` entries (see _group_blocks)."""
        style_text = str(self.style)
        min_area = self._min_area(last_zoom)
        # Below the highest zoom, lines are joined within cells of a tile's
        # size at the run's last zoom (see _vrt_layer_block).
        cell = 2 * _WORLD_HALF / 2 ** last_zoom if min_area is not None else None
        with open(vrt_path, "w", encoding="utf-8") as f:
            f.write("<OGRVRTDataSource>\n")
            for layer, entry_name, _, _ in entries:
                f.write(self._vrt_layer_block(layer, style_text, min_area, cell, entry_name))
            f.write(extra)
            f.write("</OGRVRTDataSource>\n")

    # --- Point clusters and point displacement ---

    def _group_sources(self) -> Dict[str, dict]:
        """The datasets of point grouping renderers, by name (group_sources)."""
        return group_sources(self.style.get("layers", []))

    @staticmethod
    def _group_of(name: str, sources: Dict[str, dict]) -> Optional[str]:
        """The dataset whose points group a dataset's (group_of)."""
        return group_of(name, sources)

    @staticmethod
    def _displacement_groups(points: List[tuple], search: float) -> List[List[int]]:
        """QgsPointDistanceRenderer's groups of points ((x, y) in drawing
        order): a point joins the group, among those whose first point lies
        within ``search`` of it (a square), whose centre (its points' mean)
        is nearest, else starts one. Returns each group's point indices."""
        cell = search if search > 0 else 1.0
        seeds: Dict[tuple, List[int]] = {}
        groups: List[List[int]] = []
        centres: List[List[float]] = []
        origins: List[tuple] = []
        for index, (x, y) in enumerate(points):
            cx, cy = int(math.floor(x / cell)), int(math.floor(y / cell))
            best, best_d = -1, None
            for gx in (cx - 1, cx, cx + 1):
                for gy in (cy - 1, cy, cy + 1):
                    for group in seeds.get((gx, gy), ()):
                        sx, sy = origins[group]
                        if abs(sx - x) > search or abs(sy - y) > search:
                            continue
                        mx, my = centres[group]
                        d = (mx - x) ** 2 + (my - y) ** 2
                        if best_d is None or d < best_d or (d == best_d and group < best):
                            best, best_d = group, d
            if best < 0:
                seeds.setdefault((cx, cy), []).append(len(groups))
                origins.append((x, y))
                centres.append([x, y])
                groups.append([index])
                continue
            n = len(groups[best])
            centre = centres[best]
            centre[0], centre[1] = (centre[0] * n + x) / (n + 1), (centre[1] * n + y) / (n + 1)
            groups[best].append(index)
        return groups

    @staticmethod
    def _displaced_offsets(n: int, meta: dict) -> Tuple[List[tuple], List[tuple], float]:
        """QgsPointDisplacementRenderer's positions of a group's n points
        around its centre and of their labels (at the label distance factor
        f), in screen pixels (x right, y down), and its circle's radius
        (ring placements) or grid spacing (grid)."""
        d, a, cd = meta.get("d", 0.0), meta.get("a", 0.0), meta.get("cd", 0.0)
        f = meta.get("f", 0.5)
        side = d / math.sqrt(2)
        placement = meta.get("placement", 0)
        if n == 1:
            return [(0.0, 0.0)], [(side * f, -side * f)], 0.0
        if placement == 1:  # Concentric rings.
            first = cd / 2 + d / 2
            offsets, labels, radius, ring = [], [], 0.0, 1
            while len(offsets) < n:
                radius = max(first + (ring - 1) * d + ring * a, 0)
                capacity = max(int(math.floor(2 * math.pi * radius / d)) if d > 0 else n, 1)
                count = min(capacity, n - len(offsets))
                for j in range(count):
                    theta = j * 2 * math.pi / count
                    offsets.append((radius * math.sin(theta), radius * math.cos(theta)))
                    labels.append(((radius + d * f) * math.sin(theta), (radius + d * f) * math.cos(theta)))
                ring += 1
            return offsets, labels, radius
        if placement == 2:  # Grid.
            size = int(math.ceil(math.sqrt(n)))
            if n - (size - 1) ** 2 < size:
                size -= 1
            spacing = ((cd / 2 + d / 2) + d) / 2 + a
            shift = -spacing * (size - 1) / 2
            offsets = [(spacing * (i % size) + shift, spacing * (i // size) + shift) for i in range(n)]
            labels = [(x + side * f * (-1 if x < 0 else 1), y - side * f * (1 if y < 0 else -1))
                      for x, y in offsets]
            return offsets, labels, spacing
        radius = max(d / 2, n * d / (2 * math.pi)) + a  # Ring.
        angles = [k * 2 * math.pi / n for k in range(n)]
        offsets = [(radius * math.sin(t), radius * math.cos(t)) for t in angles]
        labels = [((radius + d * f) * math.sin(t), (radius + d * f) * math.cos(t)) for t in angles]
        return offsets, labels, radius

    def _group_blocks(self, run_layers: dict, sources: Dict[str, dict],
                      tag: str) -> Tuple[str, dict]:
        """VRT entries and CONF entries of a run's grouped points: per zoom
        level, the layer's points grouped as QGIS groups them (the distance
        at that zoom). A cluster renderer's groups of several points become
        their centre, counting them in q2vt_cluster_size, its other points
        stay alone; a displacement renderer's points move where QGIS draws
        them around their group's centre, with their labels, and its groups
        become their centre, holding their circle's radius in
        q2vt_displacement_radius, or a grid's lines. Written to temporary
        files, each zoom's entry writing the dataset's own tile layer (CONF
        target_name)."""
        by_name = {self._layer_name(layer): layer for layer in self.layers}
        blocks, conf = [], {}
        cache: Dict[tuple, tuple] = {}
        for name, (layer, minzoom, maxzoom) in run_layers.items():
            group_source = self._group_of(name, sources)
            if group_source is None or group_source not in by_name:
                continue
            meta = sources[group_source]
            source = layer.source().split("|layername=")[0]
            all_source = by_name[group_source].source().split("|layername=")[0]
            role = meta.get("role") if name == group_source else sources.get(name, {}).get("role")
            clusters = meta.get("role") == "cluster"
            out_path = join(QgsProcessingUtils.tempFolder(), f"displaced_{tag}_{len(blocks)}.gpkg")
            driver = ogr.GetDriverByName("GPKG")
            out = driver.CreateDataSource(out_path)
            src = ogr.Open(source)
            if out is None or src is None:
                continue
            src_layer = src.GetLayer(0)
            fields = src_layer.GetLayerDefn()
            orig_index = fields.GetFieldIndex(f"{_FIELD_PREFIX}_orig_id")
            features = [(f.GetFID(), f.Clone()) for f in src_layer]
            # Shown beyond the highest zoom's tiles, which viewers enlarge:
            # those tiles also hold the points grouped for each zoom level
            # beyond, each copy marked with its own (GROUP_ZOOM_FIELD; the
            # style draws the one of the zoom level it is drawn at).
            last = self._parse_layer_zoom(layer, "i") if maxzoom == _TILES_MAX_ZOOM else maxzoom
            for zoom in range(minzoom, max(maxzoom, last) + 1):
                key = (group_source, zoom)
                if key not in cache:
                    cache[key] = self._grouped_points(all_source, meta, zoom)
                moved, labels, groups = cache[key]
                geometry_type = ogr.wkbMultiLineString if role == "circle" and meta.get("placement") == 2 \
                    else ogr.wkbPoint
                out_layer = out.CreateLayer(f"z{zoom:02d}", src_layer.GetSpatialRef(), geometry_type)
                for i in range(fields.GetFieldCount()):
                    field = ogr.FieldDefn(fields.GetFieldDefn(i).GetName(), fields.GetFieldDefn(i).GetType())
                    field.SetSubType(fields.GetFieldDefn(i).GetSubType())  # Any width: values kept whole.
                    out_layer.CreateField(field)
                if role == "circle":
                    out_layer.CreateField(ogr.FieldDefn(DISPLACEMENT_RADIUS_FIELD, ogr.OFTReal))
                if role == "cluster":
                    out_layer.CreateField(ogr.FieldDefn(CLUSTER_SIZE_FIELD, ogr.OFTInteger))
                if role == "label":
                    out_layer.CreateField(ogr.FieldDefn(DISPLACEMENT_ANCHOR_FIELD, ogr.OFTString))
                copies = last > _TILES_MAX_ZOOM and zoom >= _TILES_MAX_ZOOM
                if copies:
                    out_layer.CreateField(ogr.FieldDefn(GROUP_ZOOM_FIELD, ogr.OFTInteger))
                defn = out_layer.GetLayerDefn()
                out_layer.StartTransaction()
                if role in (None, "label"):
                    positions = labels if role == "label" else moved
                    for _, feature in features:
                        point = feature.GetGeometryRef()
                        if point is None:
                            continue
                        orig = feature.GetField(orig_index) if orig_index >= 0 else None
                        point_key = (orig, round(point.GetX(), 3), round(point.GetY(), 3))
                        if clusters and point_key in moved:
                            continue  # In a cluster: drawn as the cluster.
                        position = positions.get(point_key)
                        copy = ogr.Feature(defn)
                        copy.SetFrom(feature)
                        if position is not None:
                            copy.SetGeometry(ogr.CreateGeometryFromWkt(f"POINT ({position[0]!r} {position[1]!r})"))
                            if role == "label":
                                copy.SetField(DISPLACEMENT_ANCHOR_FIELD, position[2])
                        if copies:
                            copy.SetField(GROUP_ZOOM_FIELD, zoom)
                        out_layer.CreateFeature(copy)
                else:
                    by_key = {}
                    for _, feature in features:
                        point = feature.GetGeometryRef()
                        if point is not None:
                            orig = feature.GetField(orig_index) if orig_index >= 0 else None
                            by_key.setdefault((orig, round(point.GetX(), 3), round(point.GetY(), 3)), feature)
                    for first_key, centre, radius, lines, size in groups:
                        first = by_key.get(first_key)
                        copy = ogr.Feature(defn)
                        if first is not None:
                            copy.SetFrom(first)
                        if role == "circle" and lines is not None:
                            copy.SetGeometry(ogr.CreateGeometryFromWkt(lines))
                        else:
                            copy.SetGeometry(ogr.CreateGeometryFromWkt(f"POINT ({centre[0]!r} {centre[1]!r})"))
                        if role == "circle":
                            copy.SetField(DISPLACEMENT_RADIUS_FIELD, radius)
                        if role == "cluster":
                            copy.SetField(CLUSTER_SIZE_FIELD, size)
                        if copies:
                            copy.SetField(GROUP_ZOOM_FIELD, zoom)
                        out_layer.CreateFeature(copy)
                out_layer.CommitTransaction()
                entry = f"{name}__z{zoom:02d}"
                tile_zoom = min(zoom, _TILES_MAX_ZOOM)
                conf[entry] = {"target_name": name, "minzoom": tile_zoom, "maxzoom": tile_zoom}
                extra_field = {
                    "circle": f'        <Field name="{DISPLACEMENT_RADIUS_FIELD}" type="Real"/>\n',
                    "cluster": f'        <Field name="{CLUSTER_SIZE_FIELD}" type="Integer"/>\n',
                    "label": f'        <Field name="{DISPLACEMENT_ANCHOR_FIELD}" type="String"/>\n',
                }.get(role, "")
                if copies:
                    extra_field += f'        <Field name="{GROUP_ZOOM_FIELD}" type="Integer"/>\n'
                blocks.append(
                    f'    <OGRVRTLayer name={quoteattr(entry)}>\n'
                    f'        <SrcDataSource>{escape(out_path)}</SrcDataSource>\n'
                    f'        <SrcLayer>z{zoom:02d}</SrcLayer>\n'
                    f'        <LayerSRS>EPSG:{_EPSG_CRS}</LayerSRS>\n'
                    f'        <GeometryType>wkbUnknown</GeometryType>\n'
                    f'{self._vrt_fields(source, str(self.style))}{extra_field}'
                    f'    </OGRVRTLayer>\n')
            out = src = None
        return "".join(blocks), conf

    def _grouped_points(self, all_source: str, meta: dict, zoom: int) -> tuple:
        """A grouping layer's points at a zoom: {(orig id, x, y): moved
        position} (a cluster renderer: the points in a cluster), {key: its
        label's position and anchor} and its groups of several points as (first
        point's key, centre, circle radius in pixels, grid lines' WKT or
        None, number of points)."""
        resolution = 2 * _WORLD_HALF / (_TILE_PIXELS * 2 ** zoom)
        distance = meta.get("distance") or {}
        search = distance.get("m") or distance.get("px", 0) * resolution
        ds = ogr.Open(all_source)
        keys, points = [], []
        if ds is not None:
            layer = ds.GetLayer(0)
            orig_index = layer.GetLayerDefn().GetFieldIndex(f"{_FIELD_PREFIX}_orig_id")
            for feature in layer:
                point = feature.GetGeometryRef()
                if point is None:
                    continue
                orig = feature.GetField(orig_index) if orig_index >= 0 else None
                keys.append((orig, round(point.GetX(), 3), round(point.GetY(), 3)))
                points.append((point.GetX(), point.GetY()))
        ds = None
        clusters = meta.get("role") == "cluster"
        moved, labels, groups = {}, {}, []
        for members in self._displacement_groups(points, search):
            n = len(members)
            cx = sum(points[i][0] for i in members) / n
            cy = sum(points[i][1] for i in members) / n
            if clusters:
                if n > 1:
                    moved.update((keys[i], (cx, cy)) for i in members)
                    groups.append((keys[members[0]], (cx, cy), 0.0, None, n))
                continue
            offsets, label_offsets, radius = self._displaced_offsets(n, meta)
            positions = []
            for i, (dx, dy), (lx, ly) in zip(members, offsets, label_offsets):
                position = (cx + dx * resolution, cy - dy * resolution) if n > 1 else points[i]
                moved[keys[i]] = position
                origin = (cx, cy) if n > 1 else points[i]
                # QGIS draws the text on its shift's side of the point:
                # ending there to its left, hanging below it under it.
                anchor = f"{'top' if ly > 0 else 'bottom'}-{'right' if lx < 0 else 'left'}"
                labels[keys[i]] = (origin[0] + lx * resolution, origin[1] - ly * resolution, anchor)
                positions.append(position)
            if n < 2:
                continue
            lines = None
            if meta.get("placement") == 2:
                columns = int(math.ceil(math.sqrt(n)))
                if n - (columns - 1) ** 2 < columns:
                    columns -= 1
                segments = []
                for i in range(n):
                    if i + 1 < n and (i + 1) % columns != 0:
                        segments.append((positions[i], positions[i + 1]))
                    if i + columns < n:
                        segments.append((positions[i], positions[i + columns]))
                lines = "MULTILINESTRING (" + ", ".join(
                    f"({a[0]!r} {a[1]!r}, {b[0]!r} {b[1]!r})" for a, b in segments) + ")" if segments else None
            groups.append((keys[members[0]], (cx, cy), radius, lines, n))
        return moved, labels, groups

    def _min_area(self, last_zoom: Optional[int]) -> Optional[float]:
        """The smallest polygon (EPSG:3857 square metres) a run's tiles
        keep: _MIN_POLYGON_PIXELS of a screen pixel at its last zoom level,
        below which a polygon shows as no more than a faint speck. None at
        the tiles' highest zoom, whose tiles are enlarged beyond it."""
        if last_zoom is None or last_zoom >= getattr(self, "_last_zoom", last_zoom):
            return None
        pixel = 2 * _WORLD_HALF / (_TILE_PIXELS * 2 ** last_zoom)
        return _MIN_POLYGON_PIXELS * pixel * pixel

    def _vrt_layer_block(self, layer: QgsVectorLayer, style_text: str,
                         min_area: Optional[float] = None, cell: Optional[float] = None,
                         entry_name: Optional[str] = None) -> str:
        """Return the VRT XML block for a single layer, with its tiled fields
        only (see _vrt_fields): a polygon layer's smaller polygons than
        ``min_area`` are left out; a line layer's lines alike in every tiled
        field are joined where they meet within cells of ``cell`` metres (a
        network's many two-point parts then simplify, fewer to draw), and
        those left shorter than _MIN_LINE_PIXELS are left out."""
        source = layer.source().split("|layername=")[0]
        entry_name = entry_name or self._layer_name(layer)
        geometry = re.search(r"c(\d\d)", self._layer_name(layer))
        geometry = geometry.group(1) if geometry else None
        src_sql = ""
        ds = ogr.Open(source)
        if ds is not None:
            # SQL over the plugin's own dataset; names are quoted.
            def quote(text: str) -> str:
                return '"' + text.replace('"', '""') + '"'
            source_layer = ds.GetLayer(0)
            name = quote(source_layer.GetName())
            defn = source_layer.GetLayerDefn()
            names = [defn.GetFieldDefn(i).GetName() for i in range(defn.GetFieldCount())]
            tiled = [quote(n) for n in names if self._is_tiled_field(n, style_text)]
            untiled = [quote(n) for n in names if not self._is_tiled_field(n, style_text)]
            # Labels keep their lines: QGIS labels each one (joined, they
            # would be fewer, elsewhere).
            symbology = self._parse_layer_zoom(layer, "t") == 0
            columns = "".join(", " + t for t in tiled)
            if (cell and geometry == "01" and symbology and self._sqlite_geometry()
                    and not self._directed(self._layer_name(layer))):
                grid = (f"CAST(ST_MinX(geometry) / {cell!r} AS INTEGER), "
                        f"CAST(ST_MinY(geometry) / {cell!r} AS INTEGER)")
                groups = "".join(t + ", " for t in tiled)
                # A pixel at the run's last zoom (the cell is its tile).
                shortest = _MIN_LINE_PIXELS * cell / _TILE_PIXELS
                merged = "ST_LineMerge(ST_Collect(geometry))"
                sql = (f"SELECT {merged} AS geometry{columns} "
                       f"FROM {name} GROUP BY {groups}{grid} "
                       f"HAVING ST_Length({merged}) >= {shortest!r}")  # nosec B608
                src_sql = f'        <SrcSQL dialect="SQLITE">{escape(sql)}</SrcSQL>\n'
            elif (min_area and geometry == "02") or (untiled and not tiled):
                # Without <Field> elements (no tiled field) a VRT layer
                # has every field of its source: none, then.
                columns = f"* EXCLUDE ({', '.join(untiled)})" if untiled else "*"
                where = f" WHERE OGR_GEOM_AREA >= {min_area!r}" if min_area and geometry == "02" else ""
                sql = f"SELECT {columns} FROM {name}{where}"  # nosec B608
                src_sql = f'        <SrcSQL dialect="OGRSQL">{escape(sql)}</SrcSQL>\n'
            ds = None
        return (
            f'    <OGRVRTLayer name={quoteattr(entry_name)}>\n'
            f'        <SrcDataSource>{escape(source)}</SrcDataSource>\n'
            f'{src_sql}'
            f'        <LayerSRS>EPSG:{_EPSG_CRS}</LayerSRS>\n'
            f'        <GeometryType>wkbUnknown</GeometryType>\n'
            f'{self._vrt_fields(source, style_text)}'
            f'    </OGRVRTLayer>\n'
        )

    def _directed(self, name: str) -> bool:
        """Whether a dataset's lines must stay as they are: drawn along their
        direction (an offset, a pattern or a gradient), which joining them
        may reverse, or labelled (a label layer reads them, see
        share_tile_layers), where QGIS labels each line."""
        if not hasattr(self, "_directed_layers"):
            self._directed_layers = set()
            for layer_def in self.style.get("layers", []):
                paint = layer_def.get("paint", {})
                if layer_def.get("type") == "symbol" or (layer_def.get("type") == "line" and any(
                        paint.get(key) not in (None, 0) for key in ("line-offset", "line-pattern", "line-gradient"))):
                    self._directed_layers.add(layer_def.get("source-layer"))
        shared = self._shared_tile_layers()
        return name in self._directed_layers or shared.get(name) in self._directed_layers

    @staticmethod
    def _sqlite_geometry() -> bool:
        """Whether GDAL's SQLite dialect has its geometry functions
        (SpatiaLite), which joining lines needs; checked once."""
        if not hasattr(GDALTilesGenerator, "_has_sqlite_geometry"):
            has = False
            try:
                # MEM holds vectors from GDAL 3.11, which deprecates Memory.
                driver = next(d for d in map(ogr.GetDriverByName, ("MEM", "Memory"))
                              if d is not None and d.GetMetadataItem("DCAP_VECTOR") == "YES")
                ds = driver.CreateDataSource("q2vt_check")
                result = ds.ExecuteSQL(
                    "SELECT ST_NumGeometries(ST_LineMerge(ST_Collect(ST_GeomFromText("
                    "'LINESTRING(0 0, 1 1)')))) AS n", dialect="SQLITE")
                if result is not None:
                    feature = result.GetNextFeature()
                    has = bool(feature and feature.GetField(0) == 1)
                    ds.ReleaseResultSet(result)
            except (RuntimeError, AttributeError, StopIteration):
                has = False
            GDALTilesGenerator._has_sqlite_geometry = has
        return GDALTilesGenerator._has_sqlite_geometry

    @staticmethod
    def _is_tiled_field(field_name: str, style_text: str) -> bool:
        """Whether a dataset field belongs in the tiles.

        q2vt_orig_id only serves the rules export, q2vt_description is in
        the style's metadata (one per rule, not per feature), and
        data-defined property fields matter only if the style references
        them.
        """
        if field_name in (f"{_FIELD_PREFIX}_orig_id", f"{_FIELD_PREFIX}_biggest",
                          f"{_FIELD_PREFIX}_description"):
            return False
        if f"{_FIELD_PREFIX}_property_" in field_name:
            return field_name in style_text
        return True

    def _vrt_fields(self, source: str, style_text: str) -> str:
        """<Field> elements selecting the tiled fields of ``source``.

        Selecting fields in the VRT keeps the others out of the tiles without
        rewriting the dataset. Returns "" (all fields) if it can't be read.
        """
        ds = ogr.Open(source)
        if ds is None:
            return ""
        defn = ds.GetLayer(0).GetLayerDefn()
        elements = []
        for i in range(defn.GetFieldCount()):
            field = defn.GetFieldDefn(i)
            if not self._is_tiled_field(field.GetName(), style_text):
                continue
            subtype = ""
            if field.GetSubType() != ogr.OFSTNone:
                subtype = f" subtype={quoteattr(ogr.GetFieldSubTypeName(field.GetSubType()))}"
            elements.append(
                f'        <Field name={quoteattr(field.GetName())} '
                f'type={quoteattr(ogr.GetFieldTypeName(field.GetType()))}{subtype}/>\n'
            )
        ds = None
        return "".join(elements)

    # --- ogr2ogr execution ---

    def _ogr2ogr_command(self, run: _Run) -> List[str]:
        """The ogr2ogr command of one run, writing its VRT and CONF next to
        the temporary files."""
        lo, hi = run.lo, run.hi
        run_layers = self._run_layers(lo, hi)
        tag = f"{lo}_{hi}_{uuid4().hex}"
        vrt_path = join(QgsProcessingUtils.tempFolder(), f"layers_{tag}.vrt")
        conf_path = join(QgsProcessingUtils.tempFolder(), f"layers_conf_{tag}.json")
        grouped = self._group_sources()
        plain = {name: entry for name, entry in run_layers.items()
                 if self._group_of(name, grouped) is None}
        group_xml, group_conf = self._group_blocks(run_layers, grouped, tag) if grouped else ("", {})
        entries = self._entries(plain)
        self._build_vrt(vrt_path, entries, hi, group_xml)
        self._build_layer_conf(conf_path, entries, group_conf)
        run.cache_path = None
        # The temporary database is written heavily: in memory if it fits,
        # else on local disk, not next to the output (which may be a synced
        # or network folder).
        if run.in_memory:
            temporary_db = f"/vsimem/tiles_{tag}.temp.db"
        else:
            temporary_db = join(QgsProcessingUtils.tempFolder(), f"tiles_{tag}.temp.db")
        # The driver applies SIMPLIFICATION_MAX_ZOOM at a run's last zoom:
        # only the tiles' real last zoom is left unsimplified.
        simplification = _SIMPLIFICATION_LOW if hi <= _SIMPLIFICATION_LOW_ZOOM else _SIMPLIFICATION
        last_zoom_simplification = (
            _SIMPLIFICATION_MAX_ZOOM if hi >= getattr(self, "_last_zoom", hi) else simplification
        )
        command = [
            gdal_tool("ogr2ogr"), "-f", "MBTiles", run.output, vrt_path,
            # MAXZOOM also becomes the MBTiles metadata's maxzoom, from which
            # QGIS enlarges the tiles beyond it.
            "-dsco", f"MINZOOM={lo}",
            "-dsco", f"MAXZOOM={hi}",
            "-dsco", f"CONF={conf_path}",
            "-dsco", f"TEMPORARY_DB={temporary_db}",
            "-t_srs", f"EPSG:{_EPSG_CRS}",
            "-dsco", f"MAX_SIZE={self._max_tile_size(hi)}",
            "-dsco", f"MAX_FEATURES={_TILE_MAX_FEATURES}",
            "-dsco", f"SIMPLIFICATION={simplification}",
            "-dsco", f"SIMPLIFICATION_MAX_ZOOM={last_zoom_simplification}",
            *self._fine_grid(run),
            *self._strip_filter(run),
        ]
        if not group_xml:
            run.cache_path = self._cache_path(command, vrt_path, conf_path)
        return command

    def _fine_grid(self, run: _Run) -> List[str]:
        """A finer coordinate grid for the tiles viewers enlarge far: when
        the export goes to zoom _FINE_GRID_ZOOM or beyond, the last tile
        zoom's tiles are drawn several times their size, where the default
        grid (4096 units a tile, 0.3 m at zoom 15) would move vertices by a
        pixel or two. MapLibre reads any tile extent."""
        if run.hi < getattr(self, "_last_zoom", run.hi) or self._get_global_max_zoom() < _FINE_GRID_ZOOM:
            return []
        scale = _FINE_GRID_EXTENT // 4096
        return ["-dsco", f"EXTENT={_FINE_GRID_EXTENT}", "-dsco", f"BUFFER={80 * scale}"]

    def _run_ogr2ogr_runs(self, runs: List[_Run]):
        """Run ogr2ogr once per run, a worker's each, on one thread; raises
        RuntimeError if any fails, and stops them all if the conversion is
        cancelled. A run that fails with its temporary database in memory
        (e.g. out of memory) is run again with it on disk."""
        failed = self._run_processes(runs)
        retry = [run for run, _ in failed if run.in_memory]
        if retry:
            for run in retry:
                run.in_memory = False
                self._remove(run.output)
            failed = self._run_processes(retry)
        if failed:
            error_msg = f"ogr2ogr failed.\nError: {failed[0][1]}"
            if self.feedback:
                self.feedback.reportError(error_msg)
            raise RuntimeError(error_msg)

    def _run_processes(self, runs: List[_Run]) -> List[Tuple[_Run, str]]:
        """Run the runs' ogr2ogr processes, as many at once as there are
        workers, the largest estimated first; the failed runs with the end
        of their error output."""
        workers = self._worker_count()
        # Fewer processes, each with several GDAL threads (_THREADS_PER_RUN).
        concurrent = max(1, round(workers / _THREADS_PER_RUN)) if workers >= _THREADS_PER_RUN else workers
        env = gdal_tool_env()
        env["GDAL_NUM_THREADS"] = str(max(1, workers // concurrent))
        startupinfo = None
        creationflags = 0
        if os.name == "nt":
            creationflags = _CREATE_NO_WINDOW
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = 0

        processes = []
        failed = []
        waiting = sorted(runs, key=lambda r: -r.cost)
        # Per run: when it started, and how long it took.
        started: Dict[int, float] = {}
        took: Dict[int, float] = {}
        try:
            while waiting or any(process.poll() is None for _, process, _ in processes):
                if self._cancelled.is_set() or (
                        self.feedback is not None and self.feedback.isCanceled()):
                    raise RuntimeError("Tile generation cancelled.")
                for run, process, _ in processes:
                    if process.poll() is not None and id(run) not in took:
                        took[id(run)] = time.perf_counter() - started[id(run)]
                while waiting and len(processes) - len(took) < concurrent:
                    run = waiting.pop(0)
                    command = self._ogr2ogr_command(run)
                    if self._from_cache(run):
                        continue
                    stderr_path = f"{run.output}.log"
                    with open(stderr_path, "w", encoding="utf-8") as stderr:
                        started[id(run)] = time.perf_counter()
                        processes.append((run, subprocess.Popen(
                            command, env=env,
                            stdout=subprocess.DEVNULL, stderr=stderr,
                            startupinfo=startupinfo, creationflags=creationflags,
                        ), stderr_path))
                time.sleep(0.25)
            if self.feedback is not None:
                for run in runs:
                    if run.from_cache:
                        columns = f" columns {run.columns[0]}-{run.columns[1]}" if run.columns else ""
                        self.feedback.pushDebugInfo(f"Tiles z{run.lo}-{run.hi}{columns}: reused")
                for run, _, _ in processes:
                    columns = f" columns {run.columns[0]}-{run.columns[1]}" if run.columns else ""
                    seconds = took.get(id(run), time.perf_counter() - started[id(run)])
                    self.feedback.pushDebugInfo(
                        f"Tiles z{run.lo}-{run.hi}{columns}: {seconds:.1f} s"
                        f"{' (database in memory)' if run.in_memory else ''}")
            for run, process, stderr_path in processes:
                if process.returncode != 0:
                    with open(stderr_path, encoding="utf-8", errors="replace") as f:
                        failed.append((run, f.read()[-4000:]))
                else:
                    self._to_cache(run)
        finally:
            for _, process, stderr_path in processes:
                if process.poll() is None:
                    process.kill()
                    process.wait()
                self._remove(stderr_path)
        return failed

    # --- Tile runs kept between exports ---

    def _cache_dir(self) -> str:
        return join(tempfile.gettempdir(), _CACHE_DIR_NAME, "tiles")

    def _file_hash(self, path: str) -> str:
        """A dataset's content hash, computed once per export."""
        hashes = self.__dict__.setdefault("_hashes", {})
        if path not in hashes:
            digest = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(1 << 20), b""):
                    digest.update(chunk)
            hashes[path] = digest.hexdigest()
        return hashes[path]

    def _cache_path(self, command: List[str], vrt_path: str, conf_path: str) -> Optional[str]:
        """The cache entry of a run (an MBTiles file), keyed by everything
        its tiles depend on: GDAL's version, its options, its VRT with each
        dataset read as its content, its CONF; None if it can't be keyed
        (it reads files made for this export only, e.g. grouped points)."""
        if _TILE_CACHE_MAX_MB <= 0:
            return None
        try:
            with open(vrt_path, encoding="utf-8") as f:
                vrt = f.read()
            with open(conf_path, encoding="utf-8") as f:
                conf = f.read()

            def content(match):
                path = unescape(match.group(1))
                if not os.path.isfile(path) or os.path.dirname(path) == QgsProcessingUtils.tempFolder():
                    raise OSError(path)
                return f"<SrcDataSource>{self._file_hash(path)}</SrcDataSource>"
            vrt = re.sub(r"<SrcDataSource>(.*?)</SrcDataSource>", content, vrt)
        except OSError:
            return None
        options = [a for a in command[1:] if not a.startswith(("CONF=", "TEMPORARY_DB="))]
        options = [a for a in options if a not in (vrt_path,)][3:]  # After "-f MBTiles <output>".
        key = json.dumps([_TILE_CACHE_VERSION, gdal.VersionInfo(), options, vrt, conf])
        digest = hashlib.sha256(key.encode("utf-8")).hexdigest()[:40]
        return join(self._cache_dir(), f"run_{digest}.mbtiles")

    def _from_cache(self, run: _Run) -> bool:
        """Copy a run's kept tiles to its output, if kept."""
        if not run.cache_path or not os.path.isfile(run.cache_path):
            return False
        try:
            shutil.copyfile(run.cache_path, run.output)
            os.utime(run.cache_path)
        except OSError:
            return False
        run.from_cache = True
        return True

    def _to_cache(self, run: _Run) -> None:
        """Keep a finished run's tiles for later exports."""
        if not run.cache_path or run.from_cache or not os.path.isfile(run.output):
            return
        try:
            os.makedirs(self._cache_dir(), exist_ok=True)
            temp = f"{run.cache_path}.tmp_{uuid4().hex}"
            shutil.copyfile(run.output, temp)
            os.replace(temp, run.cache_path)
            self._prune_cache()
        except OSError:
            pass

    def _prune_cache(self) -> None:
        """Remove kept runs unused for too long, then the least recently
        used beyond the size limit."""
        now = time.time()
        entries = []
        for entry in os.scandir(self._cache_dir()):
            try:
                stat = entry.stat()
            except OSError:
                continue
            if now - stat.st_mtime > _CACHE_MAX_AGE_DAYS * 86400 or ".tmp_" in entry.name and now - stat.st_mtime > 86400:
                self._remove(entry.path)
            elif entry.name.endswith(".mbtiles"):
                entries.append((stat.st_mtime, stat.st_size, entry.path))
        total = sum(size for _, size, _ in entries)
        for _, size, path in sorted(entries):
            if total <= _TILE_CACHE_MAX_MB * 1024 * 1024:
                break
            self._remove(path)
            total -= size

    # --- Merging the runs' MBTiles ---

    @classmethod
    def _merge(cls, output: str, runs: List[_Run], first: int, last: int):
        """Merge the runs' MBTiles (disjoint zoom levels, or disjoint tile
        columns of one) into ``output``: each run's own tiles, and metadata
        covering all zooms and layers. A strip's run also writes partial
        tiles beside its columns, which are left out."""
        cls._remove(output)
        shutil.copyfile(runs[0].output, output)
        conn = sqlite3.connect(output)
        try:
            if runs[0].columns is not None:
                conn.execute(
                    "DELETE FROM tiles WHERE tile_column < ? OR tile_column > ?", runs[0].columns
                )
                conn.commit()
            metadata = [dict(conn.execute("SELECT name, value FROM metadata"))]
            # Attached one at a time, always under the same name.
            for run in runs[1:]:
                conn.execute("ATTACH DATABASE ? AS part", (run.output,))
                if run.columns is None:
                    conn.execute("INSERT INTO tiles SELECT * FROM part.tiles")
                else:
                    conn.execute(
                        "INSERT INTO tiles SELECT * FROM part.tiles "
                        "WHERE tile_column BETWEEN ? AND ?", run.columns
                    )
                metadata.append(dict(conn.execute("SELECT name, value FROM part.metadata")))
                conn.commit()
                conn.execute("DETACH DATABASE part")
            merged = cls._merged_metadata(metadata, first, last)
            conn.execute("DELETE FROM metadata")
            conn.executemany("INSERT INTO metadata (name, value) VALUES (?, ?)", merged.items())
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def _merged_metadata(parts: List[dict], first: int, last: int) -> dict:
        """One metadata table for the merged tiles: the zoom range, the
        bounds and the vector layers (zoom ranges, fields) of all runs."""
        merged = dict(parts[0])
        merged["name"] = "tiles"
        merged["minzoom"] = str(first)
        merged["maxzoom"] = str(last)
        boxes = []
        for meta in parts:
            try:
                boxes.append([float(v) for v in meta["bounds"].split(",")])
            except (KeyError, ValueError):
                continue
        if boxes:
            west, south = min(b[0] for b in boxes), min(b[1] for b in boxes)
            east, north = max(b[2] for b in boxes), max(b[3] for b in boxes)
            merged["bounds"] = f"{west},{south},{east},{north}"
            merged["center"] = f"{(west + east) / 2},{(south + north) / 2},{first}"
        layers: Dict[str, dict] = {}
        for meta in parts:
            try:
                vector_layers = json.loads(meta.get("json", "{}")).get("vector_layers", [])
            except ValueError:
                continue
            for layer in vector_layers:
                known = layers.get(layer.get("id"))
                if known is None:
                    layers[layer.get("id")] = dict(layer)
                    continue
                known["minzoom"] = min(known.get("minzoom", first), layer.get("minzoom", first))
                known["maxzoom"] = max(known.get("maxzoom", last), layer.get("maxzoom", last))
                known.setdefault("fields", {}).update(layer.get("fields", {}))
        merged["json"] = json.dumps({"vector_layers": list(layers.values())})
        return merged

    # --- Helpers ---

    @staticmethod
    def _remove(path: str):
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            pass

    @staticmethod
    def _layer_name(layer: QgsVectorLayer) -> str:
        """Tile layer name: the dataset's file name without extension."""
        return basename(layer.source()).split(".")[0]

    def _parse_layer_zoom(self, layer: QgsVectorLayer, marker: str) -> int:
        """Extract a zoom level from the layer filename using the given marker character."""
        return int(self._layer_name(layer).split(marker)[1][:2])

    def _get_global_min_zoom(self) -> int:
        zooms = (self._parse_layer_zoom(layer, "o") for layer in self.layers)
        return min(zooms, default=0)

    def _get_global_max_zoom(self) -> int:
        zooms = (self._parse_layer_zoom(layer, "i") for layer in self.layers)
        return max(zooms, default=14)
