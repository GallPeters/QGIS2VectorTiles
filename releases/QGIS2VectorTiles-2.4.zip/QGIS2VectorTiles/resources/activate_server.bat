@echo off

REM Kill processes using selected port
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :18111991 ^| findstr LISTENING') do (
    taskkill /PID %%a /F
)

REM Go to project root (one level above this bat file's location)
cd /d %~dp0

echo Starting MBTiles server...

REM Launch the server in a NEW window (non-blocking)
start "MBTiles Server" _Q2VT_PYTHON _Q2VT_UTILS --port 18111991

REM Give the server a moment to start before opening the browser
timeout /t 2 /nobreak > nul

REM Open the viewer in the default browser
REM (empty first string "" is a dummy title so the URL is parsed correctly)
start "" "http://localhost:18111991/maplibre_viewer.html"

pause